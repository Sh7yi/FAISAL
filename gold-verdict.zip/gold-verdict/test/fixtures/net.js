// A stand-in for the internet, used by the tests and the local demo.
// Headlines and the calendar are real ones captured on 4 Nov 2026 so the site is tested
// against real wording. The price path and past closes are sample values, not real prices.
const HEADLINES = {
  investing: [
    ['2026-11-03T23:52:00Z', 'Trump says no immediate plan to strike Iran as Netanyahu hints at attack this week', 'commodities/trump-says-no-immediate-plan'],
    ['2026-11-04T00:16:42Z', 'India gold demand seen at six-year low in 2026 as high prices and weak monsoon bite', 'commodities/india-gold-demand'],
    ['2026-11-04T01:11:18Z', 'Recap: New Zealand jobless rate hits 11-year high, kiwi slips as RBNZ hike bets fade', 'news/recap-nz'],
    ['2026-11-04T01:18:48Z', 'PBOC sets USD/ CNY mid-point today at 6.7180 (vs. estimate at 6.6811)', 'central-banks/pboc'],
    ['2026-11-04T01:53:46Z', "Sell tech, sell USD and other signals from the massive blue wave that's unfolding", 'forex/sell-tech'],
    ['2026-11-04T01:59:46Z', 'China services PMI slows to 50.8 in October as price cuts meet rising costs', 'news/china-pmi'],
    ['2026-11-04T02:26:30Z', 'Update: Iran says Hormuz stays shut until demands met as US deal remains far off', 'commodities/update-iran-hormuz'],
    ['2026-11-04T03:02:04Z', 'Nikkei drops 3% as Democratic midterm gains hit AI and chip stocks', 'stock-market-update/nikkei'],
    ['2026-11-04T03:44:09Z', "Iran's IRGC says four tankers destroyed by mines south of Hormuz, two vessels detained", 'commodities/iran-irgc-tankers'],
    ['2026-11-04T04:16:19Z', "China's yuan slides to two-week low as PBOC moves to slow its rally", 'forex/yuan'],
    ['2026-11-04T05:44:22Z', "US midterms 2026: Who would've thought that a war would be a bad idea?", 'news/us-midterms'],
    ['2026-11-04T06:20:46Z', 'US futures continue to trim losses after early beatdown but AI worries linger', 'stocks/us-futures'],
  ],
  oil: [
    ['2026-11-04T15:30:00Z', 'Brent Falls to $100 as Traders Bet on a U.S.-Iran Deal', 'latest/brent-falls'],
    ['2026-11-04T15:37:00Z', 'US Oil Inventories Fall Further As Demand Holds', 'latest/us-oil-inventories'],
    ['2026-11-04T15:00:00Z', 'Russia and Ukraine Head to White House for Melania Trump-Led Talks', 'latest/russia-ukraine-talks'],
  ],
  fed: [
    ['2026-10-29T20:30:00Z', 'Federal Reserve Board announces approval of application by The Bank of Nova Scotia', 'orders20261029a.htm'],
    ['2026-10-28T18:00:00Z', 'Federal Reserve issues FOMC statement', 'monetary20261028a.htm'],
  ],
  forex: [
    ['2026-11-04T05:26:05Z', 'NZ Q3 Labour Market Data – Potential RBNZ Implications', 'nz-q3'],
    ['2026-11-04T06:27:18Z', 'Nikkei Plunges After US Midterms, Then Rebounds — Knee-Jerk Reaction or AI Reset?', 'nikkei-plunges'],
    ['2026-11-04T07:12:00Z', 'Dollar hits one-month low as US yields fall after midterm results', 'dollar-one-month-low'],
    ['2026-11-04T09:18:00Z', 'Euro zone inflation climbs to its highest level in three years', 'ez-inflation'],
    ['2026-11-04T10:40:00Z', 'US 10-year Treasury yield falls to 4.92%, pushing borrowing costs lower', 'us-10-year'],
  ],
};

const HOSTS = {
  investing: ['investinglive.com/feed', 'https://investinglive.com/', 'investingLive'],
  oil: ['oilprice.com/rss', 'https://oilprice.com/', 'OilPrice.com'],
  fed: ['federalreserve.gov/feeds', 'https://www.federalreserve.gov/newsevents/pressreleases/', 'Federal Reserve'],
  forex: ['actionforex.com/feed', 'https://www.actionforex.com/', 'ActionForex'],
};

const CALENDAR = [
  { title: 'ISM Manufacturing PMI', country: 'USD', date: '2026-11-02T10:00:00-05:00', impact: 'Medium', forecast: '54.5', previous: '54.5' },
  { title: 'JOLTS Job Openings', country: 'USD', date: '2026-11-03T10:00:00-05:00', impact: 'Medium', forecast: '7.15M', previous: '7.08M' },
  { title: 'Congressional Elections', country: 'USD', date: '2026-11-03T10:16:00-05:00', impact: 'High', forecast: '', previous: '' },
  { title: 'Cash Rate', country: 'AUD', date: '2026-11-02T22:30:00-05:00', impact: 'High', forecast: '4.85%', previous: '4.60%' },
  { title: 'CPI Flash Estimate y/y', country: 'EUR', date: '2026-11-04T05:00:00-05:00', impact: 'Medium', forecast: '4.0%', previous: '3.8%' },
  { title: 'ADP Non-Farm Employment Change', country: 'USD', date: '2026-11-04T08:15:00-05:00', impact: 'Low', forecast: '67K', previous: '90K' },
  { title: 'Trade Balance', country: 'USD', date: '2026-11-04T08:30:00-05:00', impact: 'Low', forecast: '-107.9B', previous: '-105.6B' },
  { title: 'ISM Services PMI', country: 'USD', date: '2026-11-04T10:00:00-05:00', impact: 'Medium', forecast: '54.8', previous: '54.9' },
  { title: 'Official Bank Rate', country: 'GBP', date: '2026-11-05T07:00:00-05:00', impact: 'High', forecast: '4.00%', previous: '3.75%' },
  { title: 'Unemployment Claims', country: 'USD', date: '2026-11-05T08:30:00-05:00', impact: 'Medium', forecast: '197K', previous: '194K' },
  { title: 'Average Hourly Earnings m/m', country: 'USD', date: '2026-11-06T08:30:00-05:00', impact: 'High', forecast: '0.3%', previous: '0.1%' },
  { title: 'Non-Farm Employment Change', country: 'USD', date: '2026-11-06T08:30:00-05:00', impact: 'High', forecast: '65K', previous: '29K' },
  { title: 'Unemployment Rate', country: 'USD', date: '2026-11-06T08:30:00-05:00', impact: 'High', forecast: '4.2%', previous: '4.2%' },
  { title: 'Prelim UoM Consumer Sentiment', country: 'USD', date: '2026-11-06T10:00:00-05:00', impact: 'Medium', forecast: '48.1', previous: '46.3' },
];

const FX = { result: 'success', rates: { USD: 1, AED: 3.6725, SAR: 3.75, KWD: 0.310972, QAR: 3.64, INR: 94.928524, PKR: 276.692206, GBP: 0.745737, EUR: 0.893269, OMR: 0.3845, BHD: 0.376, EGP: 48.1, TRY: 41.2, CAD: 1.39, AUD: 1.52, SGD: 1.3, MYR: 4.2, ZAR: 17.5 } };

const OTHER_PRICES = { XAG: 48.21, XPT: 1582.4, XPD: 1411.3, HG: 5.02, BTC: 91850, ETH: 3120 };

// A made-up but plausible path for the gold price during the test run.
export function samplePrice(ms) {
  const hours = (ms - Date.UTC(2026, 10, 3, 21, 0)) / 36e5;
  const drift = 3929 + Math.min(hours, 20) * 5.9;
  return Math.round((drift + Math.sin(hours * 1.7) * 7 + Math.sin(hours * 5.3) * 3) * 100) / 100;
}

function rss(items, prefix, now) {
  const rows = items
    .filter(([date]) => new Date(date) <= now)
    .map(([date, title, slug]) => `<item><title><![CDATA[${title}]]></title><link>${prefix}${slug}</link><pubDate>${new Date(date).toUTCString()}</pubDate></item>`)
    .join('');
  return `<?xml version="1.0"?><rss version="2.0"><channel><title>Feed</title>${rows}</channel></rss>`;
}

const reply = (body, { status = 200, type = 'application/json', headers = {} } = {}) => new Response(typeof body === 'string' ? body : JSON.stringify(body), { status, headers: { 'content-type': type, ...headers } });

export function fakeNet({ now, price = samplePrice, fail = [], log = [] } = {}) {
  return async (url, options = {}) => {
    const address = String(url);
    log.push({ url: address, options });
    if (fail.some((f) => address.includes(f))) return reply('nope', { status: 503 });
    for (const [key, [match, prefix]] of Object.entries(HOSTS)) {
      if (address.includes(match)) return reply(rss(HEADLINES[key], prefix, now()), { type: 'application/rss+xml' });
    }
    if (address.includes('/price/XAU')) return reply({ name: 'Gold', symbol: 'XAU', price: price(now().getTime()), updatedAt: now().toISOString() });
    const other = address.match(/\/price\/(\w+)/);
    if (other) return reply({ symbol: other[1], price: OTHER_PRICES[other[1]] ?? 1 });
    if (address.includes('ff_calendar')) return reply(CALENDAR);
    if (address.includes('er-api')) return reply(FX);
    if (address.includes('fredgraph')) {
      const id = address.split('id=')[1];
      const values = { DGS10: ['4.98', '4.92'], DTWEXBGS: ['121.40', '120.75'], DCOILBRENTEU: ['104.20', '101.50'] }[id] ?? ['1', '2'];
      return reply(`observation_date,${id}\n2026-10-29,${values[0]}\n2026-10-30,.\n2026-11-02,${values[1]}\n`, { type: 'text/csv' });
    }
    if (address.includes('/bot')) return reply({ ok: true });
    return reply('not found', { status: 404 });
  };
}

export const SAMPLE_CLOSES = {
  '2025-12-31': 3610, '2026-09-30': 3985, '2026-10-26': 4016, '2026-10-27': 4060, '2026-10-28': 4068, '2026-10-29': 4025,
  '2026-10-30': 3874, '2026-11-02': 3947, '2026-11-03': 3929,
};

export const testSources = {
  news: [
    { name: 'investingLive', url: 'https://investinglive.com/feed/' },
    { name: 'OilPrice.com', url: 'https://oilprice.com/rss/main' },
    { name: 'Federal Reserve', url: 'https://www.federalreserve.gov/feeds/press_all.xml' },
    { name: 'ActionForex', url: 'https://www.actionforex.com/feed/' },
  ],
  goldApi: 'https://api.gold-api.com',
  calendar: 'https://nfs.faireconomy.media/ff_calendar_thisweek.json',
  fx: 'https://open.er-api.com/v6/latest/USD',
  fred: 'https://fred.stlouisfed.org/graph/fredgraph.csv',
  anthropic: 'https://api.anthropic.com/v1/messages',
  telegram: 'https://api.telegram.org',
};
