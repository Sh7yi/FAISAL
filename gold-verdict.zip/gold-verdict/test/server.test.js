import test, { after, before } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../src/server.js';
import { Collector } from '../src/collector/index.js';
import { FileStore } from '../src/store/index.js';
import { fakeNet, SAMPLE_CLOSES, testSources } from './fixtures/net.js';

const clock = { t: new Date('2026-11-04T12:00:00Z') };
const now = () => clock.t;
const config = {
  name: 'Test Gold', tagline: 'T', siteUrl: 'https://example.com', timeZone: 'Asia/Dubai', timeZoneLabel: 'Gulf time', localCurrency: 'AED',
  morningBriefHour: 7, telegramDailyLimit: 30, sources: testSources, telegramUrl: '', contactEmail: '', assetVersion: 'test',
  telegram: { token: '', chatId: '' }, ai: { key: '' }, goldApiKey: '',
};
let server;
let base;
let collector;

before(async () => {
  collector = new Collector({ config, store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: fakeNet({ now }), sleep: async () => {} });
  await collector.load();
  collector.state.closes.XAU = { ...SAMPLE_CLOSES };
  await collector.tick();
  collector.state.today.posts.push({
    id: 'xss', type: 'news', at: clock.t.toISOString(), verdict: 'bearish', importance: 'high', theme: 'fed',
    title: '<script>alert(1)</script> Gold', why: '"><img src=x onerror=alert(2)>', price: 4000, source: '<b>Evil</b>', link: 'javascript:alert(3)',
  });
  server = createServer(createApp({ config, collector, now }));
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

const PAGES = [
  '/', '/why-is-gold-moving-today', '/gold-news-calendar', '/gold-calculator', '/gold-rate', '/gold-rate/uae', '/gold-rate/india',
  '/markets', '/gold-price-history', '/guides/', '/guides/nfp', '/guides/priced-in', '/gold-today', '/gold-market-hours',
  '/gold-cheat-sheet', '/about', '/disclaimer', '/privacy', '/terms', '/status',
];

for (const path of PAGES) {
  test(`${path} opens`, async () => {
    const response = await fetch(base + path);
    assert.equal(response.status, 200);
    const text = await response.text();
    assert.match(text, /<title>.*Test Gold<\/title>/s);
    assert.match(response.headers.get('content-security-policy'), /default-src 'self'/);
    assert.doesNotMatch(text, /undefined|\[object Object\]|NaN/);
  });
}

test('the today page answers the question', async () => {
  const text = await (await fetch(`${base}/why-is-gold-moving-today`)).text();
  assert.match(text, /Why is gold up today\?/);
  assert.match(text, /Gold is up [\d.]+% today at \$/);
  assert.match(text, /The story that best fits:/);
  assert.match(text, /What moved it/);
  assert.match(text, /Spot gold, one troy ounce/);
});

test('hostile headlines cannot inject code', async () => {
  const text = await (await fetch(`${base}/why-is-gold-moving-today`)).text();
  assert.doesNotMatch(text, /<script>alert/);
  assert.doesNotMatch(text, /<img src=x/);
  assert.doesNotMatch(text, /href="javascript:/);
  assert.match(text, /&lt;script&gt;alert/);
});

test('machine endpoints work', async () => {
  assert.equal(await (await fetch(`${base}/healthz`)).text(), 'ok');
  const today = await (await fetch(`${base}/api/today`)).json();
  assert.ok(today.updatedAt && today.stream && today.hero);
  const ics = await fetch(`${base}/gold-calendar.ics`);
  assert.match(ics.headers.get('content-type'), /text\/calendar/);
  assert.match(await ics.text(), /BEGIN:VEVENT/);
  assert.match(await (await fetch(`${base}/sitemap.xml`)).text(), /<loc>https:\/\/example\.com\/gold-rate\/uae<\/loc>/);
  assert.match(await (await fetch(`${base}/robots.txt`)).text(), /Sitemap:/);
});

test('files are served, and nothing outside the public folder', async () => {
  assert.equal((await fetch(`${base}/styles.css`)).status, 200);
  assert.equal((await fetch(`${base}/app.js`)).status, 200);
  for (const path of ['/..%2f..%2fpackage.json', '/%2e%2e/site.config.json', '/gold-rate/nowhere', '/gold-today/2026-13-99', '/gold-today/1999-01-01', '/guides/nope', '/nope', '/%E0%A4%A']) {
    const response = await fetch(base + path);
    assert.equal(response.status, 404, path);
    assert.doesNotMatch(await response.text(), /"name": "gold-verdict"/);
  }
});

test('other methods are refused', async () => {
  assert.equal((await fetch(`${base}/`, { method: 'POST' })).status, 405);
});

test('an empty site still renders before the first check', async () => {
  const fresh = new Collector({ config, store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: fakeNet({ now }), sleep: async () => {} });
  const empty = createServer(createApp({ config, collector: fresh, now }));
  await new Promise((r) => empty.listen(0, r));
  const url = `http://127.0.0.1:${empty.address().port}`;
  for (const path of PAGES) {
    const response = await fetch(url + path);
    assert.equal(response.status, 200, path);
    assert.doesNotMatch(await response.text(), /undefined|\[object Object\]|NaN/, path);
  }
  empty.close();
});
