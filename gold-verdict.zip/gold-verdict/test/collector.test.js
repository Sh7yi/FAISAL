import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Collector } from '../src/collector/index.js';
import { FileStore, GitHubStore } from '../src/store/index.js';
import { buildIcs } from '../src/collector/calendar.js';
import { parseAiReply } from '../src/collector/ai.js';
import { fakeNet, SAMPLE_CLOSES, testSources } from './fixtures/net.js';

function makeConfig(extra = {}) {
  return {
    name: 'Test Gold', siteUrl: 'https://example.com', timeZone: 'Asia/Dubai', timeZoneLabel: 'Gulf time', localCurrency: 'AED',
    morningBriefHour: 7, telegramDailyLimit: 30, sources: testSources,
    telegram: { token: '', chatId: '' }, ai: { key: '', model: 'm', version: 'v', dailyLimit: 400 }, goldApiKey: '',
    ...extra,
  };
}

async function runUntil(collector, clock, end, stepMinutes = 5) {
  while (clock.t < end) {
    await collector.tick();
    clock.t = new Date(clock.t.getTime() + stepMinutes * 60000);
  }
}

test('a day of news turns into verdicts, a brief, a move alert and a close', async () => {
  const clock = { t: new Date('2026-11-03T21:00:00Z') };
  const now = () => clock.t;
  const sent = [];
  const net = fakeNet({ now, log: sent });
  const store = new FileStore(mkdtempSync(join(tmpdir(), 'gold-')));
  store.durable = true;
  const config = makeConfig({ telegram: { token: 'SECRET', chatId: '@x' } });
  const c = new Collector({ config, store, now, fetchImpl: net, sleep: async () => {} });
  await c.load();
  c.state.closes.XAU = { ...SAMPLE_CLOSES };
  delete c.state.closes.XAU['2026-11-03'];
  await runUntil(c, clock, new Date('2026-11-04T23:10:00Z'));

  const closed = await c.getDay('2026-11-04');
  assert.ok(closed, 'the finished day can be read back');
  const types = closed.posts.map((p) => p.type);
  for (const type of ['news', 'brief', 'move', 'close', 'calendar']) assert.ok(types.includes(type), `expected a ${type} post, saw ${[...new Set(types)]}`);

  const titles = closed.posts.map((p) => p.title).join('\n');
  assert.match(titles, /tankers destroyed/);
  assert.match(titles, /Morning brief for Wed 4 Nov/);
  assert.match(titles, /Gold closed Wed 4 Nov at \$/);
  assert.doesNotMatch(titles, /Nova Scotia|PBOC sets|Inventories/);

  const tanker = closed.posts.find((p) => /tankers destroyed/.test(p.title));
  assert.equal(tanker.verdict, 'bearish');
  assert.equal(tanker.importance, 'high');
  assert.ok(tanker.price > 3000, 'records the gold price when the story landed');

  assert.ok(c.state.closes.XAU['2026-11-04'] > 3000, 'records the close');
  assert.equal(c.state.today.date, '2026-11-05');
  assert.equal(c.state.days[0].date, '2026-11-04');

  // No story is posted twice.
  const ids = closed.posts.map((p) => p.id);
  assert.equal(new Set(ids).size, ids.length);

  // Telegram got posts, and the first check did not spam old news.
  const telegramCalls = sent.filter((s) => s.url.includes('/bot'));
  assert.ok(telegramCalls.length > 3);
  assert.ok(telegramCalls.length <= 30);
  const texts = telegramCalls.map((s) => JSON.parse(s.options.body).text).join('\n');
  assert.match(texts, /Bearish for gold/);
  assert.doesNotMatch(c.statusReport().telegramError ?? '', /SECRET/);

  // A reminder for ISM went out before the release.
  assert.match(titles, /Coming in \d+ minutes: US services survey/);
});

test('one source failing leaves the rest of the site working', async () => {
  const clock = { t: new Date('2026-11-04T12:00:00Z') };
  const now = () => clock.t;
  const net = fakeNet({ now, fail: ['investinglive', 'ff_calendar', 'er-api', 'fredgraph'] });
  const c = new Collector({ config: makeConfig(), store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: net, sleep: async () => {} });
  await c.load();
  await c.tick();
  assert.equal(c.state.sources['News: investingLive'].ok, false);
  assert.equal(c.state.sources['News: ActionForex'].ok, true);
  assert.equal(c.state.sources['Economic calendar'].ok, false);
  assert.ok(c.state.price.usd > 0);
  assert.equal(c.state.fx.rates.AED, 3.6725, 'pegged rates still work');
});

test('if the gold price feed is down the check still finishes', async () => {
  const clock = { t: new Date('2026-11-04T12:00:00Z') };
  const now = () => clock.t;
  const net = fakeNet({ now, fail: ['api.gold-api.com'] });
  const c = new Collector({ config: makeConfig(), store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: net, sleep: async () => {} });
  await c.load();
  await c.tick();
  assert.equal(c.state.price, null);
  assert.equal(c.state.sources['Gold price (gold-api.com)'].ok, false);
  assert.ok(c.state.lastTickAt);
});

test('a failed read of saved data never overwrites it', async () => {
  const clock = { t: new Date('2026-11-04T12:00:00Z') };
  const writes = [];
  const store = { durable: true, mode: 'github', read: async () => { throw new Error('GitHub answered 500'); }, write: async (f) => writes.push(f) };
  const c = new Collector({ config: makeConfig(), store, now: () => clock.t, fetchImpl: fakeNet({ now: () => clock.t }), sleep: async () => {} });
  await c.load();
  await c.tick();
  assert.equal(writes.length, 0);
  assert.match(c.statusReport().storageError, /500/);
});

test('saved progress is picked up again after a restart', async () => {
  const clock = { t: new Date('2026-11-04T12:00:00Z') };
  const now = () => clock.t;
  const dir = mkdtempSync(join(tmpdir(), 'gold-'));
  const first = new Collector({ config: makeConfig(), store: new FileStore(dir), now, fetchImpl: fakeNet({ now }), sleep: async () => {} });
  await first.load();
  await first.tick();
  const posts = first.state.today.posts.length;
  assert.ok(posts > 0);

  const second = new Collector({ config: makeConfig(), store: new FileStore(dir), now, fetchImpl: fakeNet({ now }), sleep: async () => {} });
  await second.load();
  clock.t = new Date(clock.t.getTime() + 300000);
  await second.tick();
  assert.equal(second.state.today.posts.length, posts, 'no duplicates after restarting');
});

test('GitHub storage saves and reads through the API', async () => {
  const objects = { ref: null, trees: new Map(), commits: new Map(), n: 0 };
  const calls = [];
  const api = async (url, options = {}) => {
    const { pathname, searchParams } = new URL(url);
    const path = pathname.replace('/repos/me/repo', '');
    const method = options.method ?? 'GET';
    calls.push(`${method} ${path}`);
    assert.equal(options.headers.authorization, 'Bearer tok');
    const body = options.body ? JSON.parse(options.body) : null;
    const json = (o, status = 200) => new Response(JSON.stringify(o), { status });
    if (method === 'GET' && path === '/git/ref/heads/data') return objects.ref ? json({ object: { sha: objects.ref } }) : json({}, 404);
    if (method === 'GET' && path.startsWith('/git/commits/')) return json({ tree: { sha: objects.commits.get(path.split('/').pop()).tree } });
    if (method === 'POST' && path === '/git/trees') {
      const sha = `tree${++objects.n}`;
      const files = new Map(body.base_tree ? objects.trees.get(body.base_tree) : []);
      for (const f of body.tree) files.set(f.path, f.content);
      objects.trees.set(sha, files);
      return json({ sha }, 201);
    }
    if (method === 'POST' && path === '/git/commits') {
      assert.deepEqual(body.parents, [], 'keeps a single commit so history does not pile up');
      const sha = `commit${++objects.n}`;
      objects.commits.set(sha, { tree: body.tree });
      return json({ sha }, 201);
    }
    if (method === 'POST' && path === '/git/refs') { objects.ref = body.sha; return json({}, 201); }
    if (method === 'PATCH' && path === '/git/refs/heads/data') { assert.equal(body.force, true); objects.ref = body.sha; return json({}); }
    if (method === 'GET' && path.startsWith('/contents/')) {
      assert.equal(searchParams.get('ref'), 'data');
      if (!objects.ref) return new Response('', { status: 404 });
      const files = objects.trees.get(objects.commits.get(objects.ref).tree);
      const name = decodeURIComponent(path.replace('/contents/', ''));
      return files.has(name) ? new Response(files.get(name)) : new Response('', { status: 404 });
    }
    throw new Error(`Unexpected ${method} ${path}`);
  };
  const store = new GitHubStore({ token: 'tok', repo: 'me/repo', fetchImpl: api, api: 'https://api.test' });
  assert.equal(await store.read('state.json'), null);
  await store.write({ 'state.json': '{"a":1}', 'days/2026-11-03.json': '{"d":1}' });
  await store.write({ 'state.json': '{"a":2}' });
  assert.equal(await store.read('state.json'), '{"a":2}');
  assert.equal(await store.read('days/2026-11-03.json'), '{"d":1}', 'older files stay in place');
  assert.ok(calls.includes('PATCH /git/refs/heads/data'));
});

test('the calendar file is valid for calendar apps', () => {
  const ics = buildIcs([{ id: 'abc', at: '2026-11-06T13:30:00.000Z', name: 'US jobs report (NFP), a very long name that keeps going so the line has to fold over', sub: '', heat: 3, higher: 'bearish', forecast: '65K', previous: '29K' }], { name: 'Test, Gold', url: 'https://example.com' });
  assert.match(ics, /^BEGIN:VCALENDAR\r\n/);
  assert.match(ics, /DTSTART:20261106T133000Z/);
  assert.match(ics, /TRIGGER:-PT15M/);
  assert.match(ics, /END:VCALENDAR\r\n$/);
  assert.match(ics, /X-WR-CALNAME:Test\\, Gold/);
  for (const line of ics.split('\r\n')) assert.ok(Buffer.byteLength(line) <= 75, `line too long: ${line}`);
});

test('AI replies are checked before use', () => {
  const out = parseAiReply('Here you go: [{"id":0,"relevant":true,"verdict":"bearish","importance":"high","theme":"oil","why":"Oil up."},{"id":1,"relevant":false},{"id":2,"verdict":"to the moon","importance":"high","why":"x"}]');
  assert.equal(out.get(0).verdict, 'bearish');
  assert.equal(out.get(1), null);
  assert.equal(out.has(2), false);
  assert.throws(() => parseAiReply('no list here'));
});

test('AI failure falls back to the built-in rules', async () => {
  const clock = { t: new Date('2026-11-04T12:00:00Z') };
  const now = () => clock.t;
  const base = fakeNet({ now });
  const seen = [];
  const net = async (url, options) => {
    if (String(url).includes('anthropic')) { seen.push(JSON.parse(options.body)); return new Response('{}', { status: 500 }); }
    return base(url, options);
  };
  const c = new Collector({ config: makeConfig({ ai: { key: 'k', model: 'claude-haiku-5-5', version: '2026-10-21', dailyLimit: 400 } }), store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: net, sleep: async () => {} });
  await c.load();
  await c.tick();
  assert.equal(seen.length, 1);
  assert.equal(seen[0].model, 'claude-haiku-5-5');
  assert.ok(c.state.today.posts.some((p) => /tankers destroyed/.test(p.title)));
  assert.equal(c.statusReport().ai, 'failing, using rules');
});

test('the weekend: Friday closes the week, Sunday announces the reopen, Monday starts fresh', async () => {
  const clock = { t: new Date('2026-11-06T20:00:00Z') };
  const now = () => clock.t;
  const c = new Collector({ config: makeConfig(), store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: fakeNet({ now, price: () => 4000 }), sleep: async () => {} });
  await c.load();
  c.state.closes.XAU = { '2026-11-05': 3950 };
  await runUntil(c, clock, new Date('2026-11-07T00:00:00Z'), 30);

  const friday = await c.getDay('2026-11-06');
  const close = friday.posts.find((p) => p.type === 'close');
  assert.match(close.title, /Gold closed for the week at \$4,000, up 1\.3%/);
  assert.equal(c.state.closes.XAU['2026-11-06'], 4000);
  assert.equal(c.state.today.date, '2026-11-07');

  await runUntil(c, clock, new Date('2026-11-08T20:00:00Z'), 60);
  assert.equal(c.state.today.date, '2026-11-08');
  assert.equal(c.state.today.snapshots.length, 0, 'no price points while the market is shut');
  assert.ok(c.state.today.posts.some((p) => p.type === 'reopen'));
  assert.equal(c.state.closes.XAU['2026-11-07'], undefined, 'Saturday is not a trading close');

  await runUntil(c, clock, new Date('2026-11-09T03:30:00Z'), 60);
  assert.equal(c.state.today.date, '2026-11-09');
  assert.ok(c.state.today.snapshots.length > 0);
});

test('waking up after a long sleep closes the missed day once, dated correctly', async () => {
  const clock = { t: new Date('2026-11-04T20:00:00Z') };
  const now = () => clock.t;
  const c = new Collector({ config: makeConfig(), store: new FileStore(mkdtempSync(join(tmpdir(), 'gold-'))), now, fetchImpl: fakeNet({ now, price: () => 4000 }), sleep: async () => {} });
  await c.load();
  c.state.closes.XAU = { '2026-11-03': 3950 };
  await c.tick();
  clock.t = new Date('2026-11-05T06:00:00Z');
  await c.tick();
  const day = await c.getDay('2026-11-04');
  const closes = day.posts.filter((p) => p.type === 'close');
  assert.equal(closes.length, 1);
  assert.equal(closes[0].at, '2026-11-04T22:00:00.000Z');
  assert.equal(c.state.today.date, '2026-11-05');
});
