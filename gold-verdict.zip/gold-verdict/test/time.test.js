import test from 'node:test';
import assert from 'node:assert/strict';
import { tradingDate, marketStatus, tradingWindow, longDate, shortDate, mondayOf } from '../src/lib/time.js';
import { changes, lastCloseBefore, newDay, newState } from '../src/core/state.js';
import { heroModel } from '../src/core/hero.js';

const at = (s) => new Date(s);

test('the gold date rolls over at 5pm New York', () => {
  // 4 Nov 2026 is after US clocks changed, so New York is UTC-5.
  assert.equal(tradingDate(at('2026-11-04T21:59:00Z')), '2026-11-04');
  assert.equal(tradingDate(at('2026-11-04T22:00:00Z')), '2026-11-05');
});

test('knows when the market is shut', () => {
  assert.equal(marketStatus(at('2026-11-04T15:00:00Z')).open, true);
  assert.equal(marketStatus(at('2026-11-04T22:30:00Z')).reason, 'break');
  assert.equal(marketStatus(at('2026-11-04T23:00:00Z')).open, true);
  const sat = marketStatus(at('2026-11-07T12:00:00Z'));
  assert.equal(sat.reason, 'weekend');
  assert.equal(sat.opensAt.toISOString(), '2026-11-08T23:00:00.000Z');
  assert.equal(marketStatus(at('2026-11-06T22:30:00Z')).reason, 'weekend');
  assert.equal(marketStatus(at('2026-11-08T22:59:00Z')).open, false);
  assert.equal(marketStatus(at('2026-11-08T23:00:00Z')).open, true);
});

test('a gold date spans 6pm the evening before to 5pm', () => {
  const { start, end } = tradingWindow('2026-11-04');
  assert.equal(start.toISOString(), '2026-11-03T23:00:00.000Z');
  assert.equal(end.toISOString(), '2026-11-04T22:00:00.000Z');
});

test('dates read naturally', () => {
  assert.equal(longDate('2026-11-04'), 'Wednesday 4 November 2026');
  assert.equal(shortDate('2026-11-04'), 'Wed 4 Nov');
  assert.equal(mondayOf('2026-11-04'), '2026-11-02');
  assert.equal(mondayOf('2026-11-08'), '2026-11-02');
});

test('changes compare against the right close', () => {
  const state = newState();
  state.today = newDay('2026-11-04');
  state.price = { usd: 4040 };
  state.closes.XAU = {
    '2025-12-31': 3000, '2026-10-30': 3874, '2026-11-02': 3947, '2026-11-03': 3929,
  };
  const c = changes(state);
  assert.equal(c.day.date, '2026-11-03');
  assert.ok(Math.abs(c.day.pct - 2.825) < 0.01);
  assert.equal(c.week.date, '2026-10-30');
  assert.equal(c.month.date, '2026-10-30');
  assert.equal(c.year.date, '2025-12-31');
  assert.equal(lastCloseBefore({}, '2026-11-04'), null);
});

test('with no history, changes are empty rather than wrong', () => {
  const state = newState();
  state.today = newDay('2026-11-04');
  state.price = { usd: 4040 };
  const c = changes(state);
  assert.equal(c.day, null);
  assert.equal(c.year, null);
});

test('the answer leads with a story that fits the move, and says so when none does', () => {
  const state = newState();
  state.today = newDay('2026-11-04');
  state.closes.XAU = { '2026-11-03': 3900 };
  state.price = { usd: 4000 };
  const post = (id, verdict, importance, title) => ({ id, type: 'news', at: '2026-11-04T10:00:00Z', verdict, importance, title, why: `Because ${id}.` });
  state.today.posts = [post('a', 'bearish', 'high', 'Tankers hit'), post('b', 'bullish', 'medium', 'Dollar slides')];
  let model = heroModel(state, at('2026-11-04T12:00:00Z'));
  assert.equal(model.question, 'Why is gold up today?');
  assert.match(model.storyLine, /^The story that best fits: Dollar slides\./);
  assert.match(model.whyLine, /Pulling the other way: Tankers hit\./);

  state.today.posts = [post('a', 'bearish', 'high', 'Is this the end?')];
  model = heroModel(state, at('2026-11-04T12:00:00Z'));
  assert.match(model.storyLine, /^The biggest story: Is this the end\? The usual reading: bearish/);
  assert.match(model.whyLine, /moving against the textbook/);
});

test('with the market shut the question looks back at the last session', () => {
  const state = newState();
  state.today = newDay('2026-11-07');
  state.closes.XAU = { '2026-11-05': 4000, '2026-11-06': 3900 };
  state.price = { usd: 3900 };
  const model = heroModel(state, at('2026-11-07T12:00:00Z'));
  assert.equal(model.question, 'Why did gold fall on Friday?');
  assert.match(model.priceLine, /ended its last session down 2\.50%/);
});
