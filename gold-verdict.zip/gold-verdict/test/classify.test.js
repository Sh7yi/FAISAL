import test from 'node:test';
import assert from 'node:assert/strict';
import { classify, sameStory } from '../src/collector/classify.js';

const cases = [
  // Real headlines from the feeds on 4 Nov 2026 and earlier.
  ["Iran's IRGC says four tankers destroyed by mines south of Hormuz, two vessels detained", 'bearish', 'high'],
  ['Update: Iran says Hormuz stays shut until demands met as US deal remains far off', 'bearish', 'high'],
  ['Brent Falls to $100 as Traders Bet on a U.S.-Iran Deal', 'bullish', 'medium'],
  ['India gold demand seen at six-year low in 2026 as high prices and weak monsoon bite', 'bearish', 'medium'],
  ['Gold falls to seven-month low below $4,000 on rising Fed hike bets, traders brace for US PCE data', 'bearish', 'medium'],
  ['Euro softens to near 1.1350 as Fed hike bets rise ahead of PCE inflation data', 'bearish', 'medium'],
  ['Inflation in the euro zone has climbed to its highest level in three years', 'bearish', 'medium'],
  ['Federal Reserve issues FOMC statement', 'mixed', 'high'],
  ['US inflation 3.7% vs 3.6% expected', 'bearish', 'high'],
  ['US inflation 3.4% vs 3.6% expected', 'bullish', 'high'],
  ['U.S. job openings beat forecasts', 'bearish', 'medium'],
  ['US weekly jobless claims rise more than expected', 'bullish', 'medium'],
  ['Nonfarm payrolls miss expectations as hiring slows', 'bullish', 'high'],
  ['Dollar hits one-month low as yields retreat', 'bullish', 'medium'],
  ['Dollar steady as gold rises', null, null],
  ['Fed cuts interest rates by a quarter point', 'bullish', 'high'],
  ['Fed raises rates and signals more to come', 'bearish', 'high'],
  ['Fed hike bets fade after soft data', 'bullish', 'medium'],
  ['Trump says no immediate plan to strike Iran as Netanyahu hints at attack this week', 'mixed', 'medium'],
  ['US midterms 2026: Democrats take control of the Senate', 'mixed', 'medium'],
  ['Democrats won control of the Senate', 'mixed', 'medium'],
  ['Monetary policy decisions', 'mixed', 'medium'],
];

for (const [title, verdict, importance] of cases) {
  test(`reads: ${title}`, () => {
    const hit = classify(title);
    if (verdict === null) assert.equal(hit, null);
    else {
      assert.ok(hit, 'expected a reading');
      assert.equal(hit.verdict, verdict);
      assert.equal(hit.importance, importance);
      assert.ok(hit.why.length > 20);
    }
  });
}

const ignored = [
  'Federal Reserve Board announces approval of application by The Bank of Nova Scotia',
  'Recap: New Zealand jobless rate hits 11-year high, kiwi slips as RBNZ hike bets fade',
  'PBOC sets USD/ CNY mid-point today at 6.7180 (vs. estimate at 6.6811)',
  'China services PMI slows to 50.8 in October as price cuts meet rising costs',
  'US Oil Inventories Fall Further As Demand Holds',
  'Tesla misled South Korean buyers over Full Self-Driving, consumer group alleges',
  'Codelco, BHP launch $40M copper hunt in northern Chile',
  'Goldman Sachs raises its stock forecast',
  'Philip R. Lane: AI adoption in Europe',
  'Nikkei drops 3% as Democratic midterm gains hit AI and chip stocks',
];

for (const title of ignored) {
  test(`ignores: ${title}`, () => assert.equal(classify(title), null));
}

test('spots the same story from two publishers', () => {
  assert.ok(sameStory('Iran says four tankers destroyed by mines near Hormuz', 'Four tankers destroyed by mines near Hormuz, Iran says'));
  assert.ok(!sameStory('Iran says four tankers destroyed by mines near Hormuz', 'US job openings beat forecasts in September'));
});
