import test from 'node:test';
import assert from 'node:assert/strict';
import { parseFeed } from '../src/collector/rss.js';

test('reads an RSS feed with CDATA links and dates in several styles', () => {
  const xml = `<rss><channel><title>Feed</title>
    <item><title>Federal Reserve issues FOMC statement</title>
      <link><![CDATA[https://www.federalreserve.gov/newsevents/pressreleases/monetary20261028a.htm]]></link>
      <pubDate><![CDATA[Wed, 28 Oct 2026 18:00:00 GMT]]></pubDate></item>
    <item><title><![CDATA[Gold &amp; silver: it&#39;s &ldquo;up&rdquo;]]></title><link>https://example.com/a</link>
      <pubDate>Thu, 25 Jun 2026 00:19:52 Z</pubDate></item>
    <item><title>Brent Falls to $100</title><link>https://example.com/b</link>
      <pubDate>Wed, 04 Nov 2026 09:30:00 -0600</pubDate></item>
    <item><title>No link here</title></item>
  </channel></rss>`;
  const items = parseFeed(xml, 'Test');
  assert.equal(items.length, 3);
  assert.equal(items[0].link, 'https://www.federalreserve.gov/newsevents/pressreleases/monetary20261028a.htm');
  assert.equal(items[0].date.toISOString(), '2026-10-28T18:00:00.000Z');
  assert.equal(items[1].title, 'Gold & silver: it\'s “up”');
  assert.equal(items[1].date.toISOString(), '2026-06-25T00:19:52.000Z');
  assert.equal(items[2].date.toISOString(), '2026-11-04T15:30:00.000Z');
  assert.equal(items[2].source, 'Test');
});

test('reads an Atom feed', () => {
  const xml = `<feed><entry><title type="html">A &lt;b&gt;bold&lt;/b&gt; title</title>
    <link rel="self" href="https://example.com/self"/><link rel="alternate" href="https://example.com/post"/>
    <published>2026-11-04T10:00:00Z</published></entry></feed>`;
  const [item] = parseFeed(xml);
  assert.equal(item.title, 'A bold title');
  assert.equal(item.link, 'https://example.com/post');
});

test('survives rubbish input', () => {
  assert.deepEqual(parseFeed('<html>not a feed</html>'), []);
  assert.deepEqual(parseFeed(''), []);
});
