// Runs in the visitor's browser: live price, currency switch, local times,
// chart hover, the calculator, and pulling in new stories without a reload.
(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  let data = {};
  try { data = JSON.parse($('#site-data').textContent); } catch { /* the page still works without it */ }
  const fx = data.fx || { USD: 1 };

  const saved = {
    get(key) { try { return localStorage.getItem(key); } catch { return null; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch { /* private browsing */ } },
  };

  let currency = saved.get('gold-currency') || 'USD';
  if (!fx[currency]) currency = 'USD';
  let price = data.price;
  let base = data.base || {};

  const SYMBOL = { USD: '$', GBP: '£', EUR: '€' };
  const money = (value, cur, digits) => {
    const number = value.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
    return SYMBOL[cur] ? `${SYMBOL[cur]}${number}` : `${cur} ${number}`;
  };
  const whole = (cur) => (fx[cur] > 50 ? 0 : 2);

  const shortTime = new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' });
  const dayTime = new Intl.DateTimeFormat(undefined, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  function localiseTimes(root = document) {
    $$('[data-time]', root).forEach((el) => {
      const when = new Date(el.dataset.time);
      if (!Number.isNaN(when.getTime())) el.textContent = (el.dataset.fmt === 'dhm' ? dayTime : shortTime).format(when);
    });
  }

  function paintChanges() {
    $$('[data-change]').forEach((row) => {
      const key = row.dataset.change;
      if (key === 'day' && !data.live) return;
      const from = base[key];
      if (!from || !price) return;
      const diff = price - from;
      const percent = (diff / from) * 100;
      const local = Math.abs(diff) * fx[currency];
      $('[data-part="abs"]', row).textContent = `${diff >= 0 ? '+' : '−'}${money(local, currency, fx[currency] > 50 ? 0 : (local < 100 ? 2 : 0))}`;
      $('[data-part="pct"]', row).textContent = `${percent > 0 ? '+' : percent < 0 ? '−' : ''}${Math.abs(percent).toFixed(2)}%`;
      row.className = `change change-${percent > 0.005 ? 'up' : percent < -0.005 ? 'down' : 'flat'}`;
    });
  }

  function paintHero() {
    const line = $('[data-hero-price]');
    const question = $('[data-question]');
    if (!line || !data.live || !base.day || !price) return;
    const percent = ((price - base.day) / base.day) * 100;
    const shown = money(price * fx[currency], currency, 0);
    const size = Math.abs(percent).toFixed(2);
    if (percent > 0.03) {
      line.textContent = `Gold is up ${size}% today at ${shown}.`;
      if (question) question.textContent = 'Why is gold up today?';
    } else if (percent < -0.03) {
      line.textContent = `Gold is down ${size}% today at ${shown}.`;
      if (question) question.textContent = 'Why is gold down today?';
    } else {
      line.textContent = `Gold is flat today at ${shown}.`;
      if (question) question.textContent = 'Why is gold flat today?';
    }
  }

  function paintRates() {
    if (!price) return;
    $$('[data-live]').forEach((cell) => {
      const rate = fx[cell.dataset.cur];
      if (rate) cell.textContent = (price * rate * Number(cell.dataset.live)).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    });
  }

  function paintPrice() {
    if (price) $$('[data-price]').forEach((el) => { el.textContent = money(price * fx[currency], currency, fx[currency] > 50 ? 0 : 2); });
    $$('[data-currency]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.currency === currency)));
    const more = $('[data-currency-more]');
    if (more) more.value = $(`[data-currency="${currency}"]`) ? '' : currency;
    paintChanges();
    paintHero();
    paintRates();
    paintCalculator();
  }

  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-currency]');
    if (!button) return;
    currency = button.dataset.currency;
    saved.set('gold-currency', currency);
    paintPrice();
  });
  document.addEventListener('change', (event) => {
    if (!event.target.matches('[data-currency-more]') || !event.target.value) return;
    currency = event.target.value;
    saved.set('gold-currency', currency);
    paintPrice();
  });

  // Live price, straight from the feed, while the tab is open.
  const usesPrice = $('[data-price]') || $('[data-live]') || $('[data-calc]');
  async function refreshPrice() {
    if (document.visibilityState === 'hidden') return;
    const label = $('[data-price-state]');
    try {
      const response = await fetch('https://api.gold-api.com/price/XAU');
      if (!response.ok) throw new Error('price feed unavailable');
      const quote = await response.json();
      if (quote.price > 0) {
        price = quote.price;
        paintPrice();
        if (label) label.textContent = `Live, checked ${shortTime.format(new Date())}`;
      }
    } catch {
      if (label) label.textContent = 'Showing the last saved price';
    }
  }
  if (usesPrice) {
    refreshPrice();
    setInterval(refreshPrice, 30000);
  }

  // Chart hover: a line that follows the pointer and reads off the nearest price.
  function bindCharts(root = document) {
    $$('.plot', root).forEach((plot) => {
      const cross = $('.cross', plot);
      const tip = $('.tip', plot);
      let points;
      try { points = JSON.parse(plot.dataset.points); } catch { return; }
      const start = Number(plot.dataset.start);
      const end = Number(plot.dataset.end);
      const daily = plot.classList.contains('plot-history');
      const dateOnly = new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
      plot.addEventListener('pointermove', (event) => {
        const box = plot.getBoundingClientRect();
        const wanted = start + ((event.clientX - box.left) / box.width) * (end - start);
        let nearest = points[0];
        for (const point of points) if (Math.abs(point[0] - wanted) < Math.abs(nearest[0] - wanted)) nearest = point;
        const left = ((nearest[0] - start) / (end - start)) * 100;
        cross.hidden = false;
        tip.hidden = false;
        cross.style.left = `${left}%`;
        tip.textContent = '';
        const value = document.createElement('b');
        value.textContent = money(nearest[1], 'USD', 2);
        tip.append(value, ` at ${(daily ? dateOnly : shortTime).format(new Date(nearest[0]))}`);
        if (daily) tip.lastChild.textContent = ` on ${dateOnly.format(new Date(nearest[0]))}`;
        tip.style.left = left > 60 ? 'auto' : `calc(${left}% + 8px)`;
        tip.style.right = left > 60 ? `calc(${100 - left}% + 8px)` : 'auto';
      });
      plot.addEventListener('pointerleave', () => { cross.hidden = true; tip.hidden = true; });
    });
  }

  // Calculator
  function paintCalculator() {
    const form = $('[data-calc]');
    if (!form || !price) return;
    const fields = new FormData(form);
    const weight = Math.max(0, Number(fields.get('weight')) || 0);
    const grams = weight * Number(fields.get('unit'));
    const karat = Number(fields.get('karat'));
    const cur = fields.get('currency');
    const making = Math.max(0, Number(fields.get('making')) || 0);
    const pureGrams = grams * (karat / 24);
    const metal = (pureGrams / 31.1034768) * price * (fx[cur] || 1);
    const total = metal * (1 + making / 100);
    $('[data-calc-value]').textContent = money(total, cur, 2);
    const parts = [`${grams.toLocaleString('en-US', { maximumFractionDigits: 2 })} g at ${karat} karat holds ${pureGrams.toLocaleString('en-US', { maximumFractionDigits: 2 })} g of pure gold.`];
    if (making > 0) parts.push(`The making charge adds ${money(total - metal, cur, 2)}.`);
    $('[data-calc-detail]').textContent = parts.join(' ');
  }
  const form = $('[data-calc]');
  if (form) {
    form.addEventListener('input', paintCalculator);
    form.addEventListener('submit', (event) => event.preventDefault());
  }

  // New stories arrive without a reload.
  const stream = $('[data-stream]');
  async function refreshStories() {
    if (document.visibilityState === 'hidden') return;
    try {
      const response = await fetch('/api/today');
      if (!response.ok) return;
      const fresh = await response.json();
      if (!fresh.updatedAt || fresh.updatedAt === data.updatedAt) return;
      if (fresh.date && data.date && fresh.date !== data.date) { location.reload(); return; }
      const known = new Set($$('.post', stream).map((post) => post.id));
      const had = known.size > 0;
      data.updatedAt = fresh.updatedAt;
      data.date = fresh.date;
      if (fresh.base) base = fresh.base;
      stream.innerHTML = fresh.stream;
      const swap = (selector, content) => { const el = $(selector); if (el) el.innerHTML = content; };
      swap('[data-moved]', fresh.moved);
      swap('[data-coming]', fresh.coming);
      swap('[data-hero]', fresh.hero);
      swap('[data-chart]', fresh.chart);
      if (had) $$('.post', stream).forEach((post) => { if (!known.has(post.id)) post.classList.add('post-new'); });
      localiseTimes();
      bindCharts($('[data-chart]') || document);
      paintPrice();
    } catch { /* try again next time */ }
  }
  if (stream) setInterval(refreshStories, 60000);

  localiseTimes();
  bindCharts();
  paintPrice();
})();
