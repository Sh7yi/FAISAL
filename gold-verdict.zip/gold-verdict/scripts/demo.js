// Fills the site with sample data and runs it on your own computer, with no internet needed.
// Run it with: npm run demo   then open http://localhost:3000
// Headlines are real ones from 4 Nov 2026. The price line and past closes are made up.
import { createServer } from 'node:http';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { loadConfig } from '../src/config.js';
import { createApp } from '../src/server.js';
import { Collector } from '../src/collector/index.js';
import { FileStore } from '../src/store/index.js';
import { fakeNet, SAMPLE_CLOSES, testSources } from '../test/fixtures/net.js';

const config = { ...loadConfig(), sources: testSources, siteUrl: process.env.DEMO_URL || 'http://localhost:3000', telegram: { token: '', chatId: '' }, ai: { key: '' }, goldApiKey: '' };
const clock = { t: new Date('2026-11-03T21:30:00Z') };
const end = new Date(process.env.DEMO_END || '2026-11-04T16:20:00Z');
const now = () => clock.t;
const store = new FileStore(mkdtempSync(join(tmpdir(), 'gold-demo-')));
store.durable = true;
const collector = new Collector({ config, store, now, fetchImpl: fakeNet({ now }), sleep: async () => {} });
await collector.load();
collector.state.closes.XAU = { ...SAMPLE_CLOSES };
delete collector.state.closes.XAU['2026-11-03'];
while (clock.t < end) {
  await collector.tick();
  clock.t = new Date(clock.t.getTime() + 5 * 60000);
}
await collector.tick();
const port = Number(process.env.PORT) || 3000;
createServer(createApp({ config, collector, now })).listen(port, () => {
  console.log(`Demo running at http://localhost:${port} (posts today: ${collector.state.today.posts.length})`);
});
