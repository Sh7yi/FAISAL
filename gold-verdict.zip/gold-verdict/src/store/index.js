import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, normalize } from 'node:path';

// Saves to a folder. On Render's free plan this folder is wiped on every restart,
// so it is only the fallback for when no GitHub token has been added.
export class FileStore {
  constructor(dir) {
    this.dir = dir;
    this.durable = false;
    this.mode = 'temporary';
  }

  #path(path) {
    const clean = normalize(path);
    if (clean.startsWith('..')) throw new Error('Bad path');
    return join(this.dir, clean);
  }

  async read(path) {
    try {
      return await readFile(this.#path(path), 'utf8');
    } catch (error) {
      if (error.code === 'ENOENT') return null;
      throw error;
    }
  }

  async write(files) {
    for (const [path, content] of Object.entries(files)) {
      const file = this.#path(path);
      await mkdir(dirname(file), { recursive: true });
      await writeFile(file, content);
    }
  }
}

// Saves to a separate "data" branch of your GitHub repo. Each save replaces the
// branch's single commit, so the repo does not grow with thousands of commits.
export class GitHubStore {
  constructor({ token, repo, branch = 'data', api = 'https://api.github.com', fetchImpl = fetch }) {
    this.token = token;
    this.repo = repo;
    this.branch = branch;
    this.api = api.replace(/\/$/, '');
    this.fetch = fetchImpl;
    this.durable = true;
    this.mode = 'github';
  }

  async #call(path, { method = 'GET', body, accept = 'application/vnd.github+json', allow404 = false } = {}) {
    const response = await this.fetch(`${this.api}/repos/${this.repo}${path}`, {
      method,
      headers: {
        authorization: `Bearer ${this.token}`,
        accept,
        'x-github-api-version': '2022-11-28',
        'user-agent': 'gold-verdict-site',
        ...(body ? { 'content-type': 'application/json' } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(20000),
    });
    if (allow404 && response.status === 404) return null;
    if (!response.ok) throw new Error(`GitHub answered ${response.status} on ${method} ${path.split('?')[0]}`);
    return accept.includes('raw') ? response.text() : response.json();
  }

  async read(path) {
    const encoded = path.split('/').map(encodeURIComponent).join('/');
    return this.#call(`/contents/${encoded}?ref=${this.branch}`, { accept: 'application/vnd.github.raw+json', allow404: true });
  }

  async write(files) {
    const ref = await this.#call(`/git/ref/heads/${this.branch}`, { allow404: true });
    let baseTree;
    if (ref) baseTree = (await this.#call(`/git/commits/${ref.object.sha}`)).tree.sha;
    const tree = await this.#call('/git/trees', {
      method: 'POST',
      body: {
        ...(baseTree ? { base_tree: baseTree } : {}),
        tree: Object.entries(files).map(([path, content]) => ({ path, mode: '100644', type: 'blob', content })),
      },
    });
    const commit = await this.#call('/git/commits', {
      method: 'POST',
      body: { message: 'Update site data', tree: tree.sha, parents: [] },
    });
    if (ref) {
      await this.#call(`/git/refs/heads/${this.branch}`, { method: 'PATCH', body: { sha: commit.sha, force: true } });
    } else {
      await this.#call('/git/refs', { method: 'POST', body: { ref: `refs/heads/${this.branch}`, sha: commit.sha } });
    }
  }
}

export function createStore(config, fetchImpl = fetch) {
  const { token, repo, branch, api } = config.github;
  if (token && repo) return new GitHubStore({ token, repo, branch, api, fetchImpl });
  return new FileStore(config.dataDir);
}
