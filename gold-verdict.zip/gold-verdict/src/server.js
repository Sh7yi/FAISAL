import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize, sep } from 'node:path';
import { gzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { loadConfig, ROOT } from './config.js';
import { createStore } from './store/index.js';
import { Collector } from './collector/index.js';
import { buildIcs } from './collector/calendar.js';
import { archivePage, dayPage, todayFragment, todayPage } from './views/today.js';
import {
  aboutPage, calculatorPage, calendarPage, cheatSheetPage, countryPage, COUNTRIES, disclaimerPage, guidePage, guidesIndex,
  historyPage, marketHoursPage, marketsPage, notFoundPage, privacyPage, ratePage, statusPage, termsPage,
} from './views/pages.js';
import { isValidDate } from './lib/time.js';
import { GUIDES } from './content/guides.js';

const PUBLIC = join(ROOT, 'public');
const TYPES = {
  '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};

const SECURITY = {
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'x-frame-options': 'DENY',
  'content-security-policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    'font-src https://fonts.gstatic.com',
    'img-src \'self\' data:',
    'connect-src \'self\' https://api.gold-api.com',
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'none'",
  ].join('; '),
};

function send(req, res, status, body, headers = {}) {
  const text = typeof body === 'string' || Buffer.isBuffer(body) ? body : String(body);
  const buffer = Buffer.isBuffer(text) ? text : Buffer.from(text);
  const type = headers['content-type'] ?? 'text/html; charset=utf-8';
  const compress = buffer.length > 1024 && /gzip/.test(req.headers['accept-encoding'] ?? '') && /text|javascript|json|svg|calendar|xml/.test(type);
  const payload = compress ? gzipSync(buffer) : buffer;
  res.writeHead(status, {
    'content-type': type,
    'cache-control': 'no-cache',
    ...SECURITY,
    ...headers,
    ...(compress ? { 'content-encoding': 'gzip', vary: 'accept-encoding' } : {}),
    'content-length': payload.length,
  });
  res.end(req.method === 'HEAD' ? undefined : payload);
}

async function serveStatic(req, res, pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    return false;
  }
  const file = normalize(join(PUBLIC, decoded));
  if (!file.startsWith(PUBLIC + sep)) return false;
  try {
    const data = await readFile(file);
    send(req, res, 200, data, {
      'content-type': TYPES[extname(file)] ?? 'application/octet-stream',
      'cache-control': 'public, max-age=86400',
    });
    return true;
  } catch {
    return false;
  }
}

function sitemap(config, state) {
  const base = config.siteUrl;
  const paths = [
    '/why-is-gold-moving-today', '/gold-news-calendar', '/gold-calculator', '/gold-rate', '/markets', '/guides/', '/gold-today',
    '/gold-price-history', '/gold-market-hours', '/gold-cheat-sheet', '/about', '/disclaimer', '/privacy', '/terms',
    ...COUNTRIES.map((c) => `/gold-rate/${c.slug}`),
    ...GUIDES.map((g) => `/guides/${g.slug}`),
    ...state.days.slice(0, 400).map((d) => `/gold-today/${d.date}`),
  ];
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${paths.map((p) => `<url><loc>${base}${p}</loc></url>`).join('\n')}\n</urlset>\n`;
}

export function createApp({ config, collector, now = () => new Date() }) {
  return async function handle(req, res) {
    try {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        return send(req, res, 405, 'Method not allowed', { 'content-type': 'text/plain; charset=utf-8', allow: 'GET, HEAD' });
      }
      let pathname;
      try {
        ({ pathname } = new URL(req.url, 'http://localhost'));
      } catch {
        return send(req, res, 400, 'Bad address', { 'content-type': 'text/plain; charset=utf-8' });
      }
      const state = collector.state;
      const ctx = { state, config, now: now() };
      const page = (view) => send(req, res, 200, view.toString());

      switch (pathname) {
        case '/':
        case '/why-is-gold-moving-today':
          return page(todayPage({ ...ctx, path: pathname }));
        case '/healthz':
          return send(req, res, 200, 'ok', { 'content-type': 'text/plain; charset=utf-8' });
        case '/api/today':
          return send(req, res, 200, JSON.stringify(todayFragment(state, config, ctx.now)), { 'content-type': 'application/json; charset=utf-8' });
        case '/gold-calendar.ics':
          return send(req, res, 200, buildIcs(state.calendar.events, { name: config.name, url: config.siteUrl || null, now: ctx.now }), {
            'content-type': 'text/calendar; charset=utf-8',
            'content-disposition': 'inline; filename="gold-calendar.ics"',
            'cache-control': 'public, max-age=1800',
          });
        case '/gold-news-calendar': return page(calendarPage(ctx));
        case '/gold-calculator': return page(calculatorPage(ctx));
        case '/gold-rate': return page(ratePage(ctx));
        case '/markets': return page(marketsPage(ctx));
        case '/gold-price-history': return page(historyPage(ctx));
        case '/guides':
        case '/guides/': return page(guidesIndex(ctx));
        case '/gold-today':
        case '/gold-today/': return page(archivePage(ctx));
        case '/gold-market-hours': return page(marketHoursPage(ctx));
        case '/gold-cheat-sheet': return page(cheatSheetPage(ctx));
        case '/about': return page(aboutPage(ctx));
        case '/disclaimer': return page(disclaimerPage(ctx));
        case '/privacy': return page(privacyPage(ctx));
        case '/terms': return page(termsPage(ctx));
        case '/status': return page(statusPage({ ...ctx, report: collector.statusReport() }));
        case '/robots.txt':
          return send(req, res, 200, `User-agent: *\nAllow: /\nDisallow: /status\nDisallow: /api/\n${config.siteUrl ? `Sitemap: ${config.siteUrl}/sitemap.xml\n` : ''}`, { 'content-type': 'text/plain; charset=utf-8' });
        case '/sitemap.xml':
          return send(req, res, 200, sitemap(config, state), { 'content-type': 'application/xml; charset=utf-8' });
        default:
      }

      const guide = pathname.match(/^\/guides\/([a-z0-9-]+)$/);
      if (guide) {
        const view = guidePage({ ...ctx, slug: guide[1] });
        if (view) return page(view);
      }
      const country = pathname.match(/^\/gold-rate\/([a-z-]+)$/);
      if (country) {
        const match = COUNTRIES.find((c) => c.slug === country[1]);
        if (match) return page(countryPage({ ...ctx, country: match }));
      }
      const day = pathname.match(/^\/gold-today\/(\d{4}-\d{2}-\d{2})$/);
      if (day && isValidDate(day[1])) {
        const doc = await collector.getDay(day[1]);
        if (doc) return page(dayPage({ ...ctx, day: doc }));
      }
      if (await serveStatic(req, res, pathname)) return undefined;
      return send(req, res, 404, notFoundPage(ctx).toString());
    } catch (error) {
      console.error('request failed', req.url, error);
      return send(req, res, 500, 'Something went wrong on our side. Please try again in a moment.', { 'content-type': 'text/plain; charset=utf-8' });
    }
  };
}

export function start(config = loadConfig()) {
  const store = createStore(config);
  const collector = new Collector({ config, store, log: (...args) => console.log(new Date().toISOString(), ...args) });
  const server = createServer(createApp({ config, collector }));
  server.listen(config.port, '0.0.0.0', () => {
    console.log(`${config.name} listening on port ${config.port}. History storage: ${store.mode}.`);
  });
  let timer;
  if (config.runCollector) {
    collector.load().then(() => collector.tick());
    timer = setInterval(() => collector.tick(), config.tickMinutes * 60000);
  }
  const stop = async () => {
    clearInterval(timer);
    const force = setTimeout(() => process.exit(0), 8000);
    force.unref();
    server.close();
    await collector.persist(new Date(), { force: true }).catch(() => {});
    process.exit(0);
  };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
  return { server, collector };
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) start();
