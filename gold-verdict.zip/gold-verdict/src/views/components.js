import { html, raw, safeUrl } from '../lib/html.js';
import { clock, dateInZone, shortDate } from '../lib/time.js';
import { money } from '../lib/format.js';

const VERDICT_TEXT = { bullish: 'Bullish for gold', bearish: 'Bearish for gold', mixed: 'Mixed for gold' };
const HEAT_TEXT = { high: 'High impact', medium: 'Medium impact' };

// A hallmark-style punch for each verdict. The shape differs, so colour is never the only signal.
const STAMPS = {
  bullish: '<path d="M10 1 19 8v11H1V8z"/><path class="glyph" d="M10 6.500 14 12.500H6z"/>',
  bearish: '<path d="M1 1h18v11l-9 7-9-7z"/><path class="glyph" d="M10 13.500 6 7.500h8z"/>',
  mixed: '<path d="M10 .500 19.500 10 10 19.500.500 10z"/><path class="glyph" d="M5.800 8.800h8.400v2.400H5.800z"/>',
};

export const stamp = (verdict) => raw(`<svg class="stamp stamp-${verdict}" viewBox="0 0 20 20" aria-hidden="true">${STAMPS[verdict] ?? ''}</svg>`);

export function time(iso, config, fmt = 'hm') {
  const date = new Date(iso);
  const fallback = fmt === 'hm' ? clock(date, config.timeZone) : `${shortDate(dateInZone(date, config.timeZone))}, ${clock(date, config.timeZone)}`;
  return html`<time datetime="${iso}" data-time="${iso}" data-fmt="${fmt}">${fallback}</time>`;
}

export function verdictLine(post) {
  if (!post.verdict) return '';
  return html`<p class="verdict verdict-${post.verdict}">${stamp(post.verdict)}<strong>${VERDICT_TEXT[post.verdict]}</strong>${HEAT_TEXT[post.importance] ? html`<span class="heat heat-${post.importance}">${HEAT_TEXT[post.importance]}</span>` : ''}</p>`;
}

function itemList(items, config) {
  if (!items?.length) return '';
  return html`<ul class="post-items">${items.map((item) => {
    const link = safeUrl(item.link);
    return html`<li>${link ? html`<a href="${link}" rel="noopener nofollow">${item.title}</a>` : item.title}${item.source ? html` <span class="src">${item.source}</span>` : ''}</li>`;
  })}</ul>`;
}

const LABEL = { news: 'News', developing: 'Developing', move: 'Price move', brief: 'Morning brief', close: 'Close', reopen: 'Market', calendar: 'Calendar' };

function postBody(post, config) {
  const link = safeUrl(post.link);
  switch (post.type) {
    case 'news':
      return html`${verdictLine(post)}
        <h3>${post.title}</h3>
        <p class="why"><b>Why:</b> ${post.why}</p>
        <p class="post-foot">${post.price ? html`<span>Gold ${money(post.price, 'USD', 2)} when this landed</span>` : ''}${link ? html`<a href="${link}" rel="noopener nofollow">Read it at ${post.source}</a>` : ''}</p>`;
    case 'developing':
      return html`${verdictLine(post)}
        <h3>${post.title}</h3>
        ${itemList(post.items, config)}
        <p class="why"><b>What it means:</b> ${post.why}</p>
        ${post.price ? html`<p class="post-foot"><span>Gold ${money(post.price, 'USD', 2)}</span></p>` : ''}`;
    case 'move':
      return html`<h3>${post.title}</h3><p class="why">${post.why}</p>${itemList(post.items, config)}`;
    case 'brief':
      return html`${verdictLine(post)}<h3>${post.title}</h3>
        ${post.sections.map((s) => html`<div class="brief-part"><h4>${s.heading}</h4>
          <ul>${s.events
            ? s.events.map((e) => html`<li>${time(e.at, config)}: ${e.name}${e.forecast ? ` (expected ${e.forecast}${e.previous ? `, last time ${e.previous}` : ''})` : ''}</li>`)
            : s.rows.map((r) => html`<li>${r}</li>`)}</ul></div>`)}`;
    case 'close':
      return html`<h3>${post.title}</h3>${post.why ? html`<p class="why">${post.why}</p>` : ''}`;
    case 'reopen':
      return html`<h3>${post.title}</h3><p class="why">That is ${time(post.opensAt, config, 'dhm')} your time.</p>`;
    case 'calendar':
      return html`<h3>${post.title}</h3>
        ${post.items?.length ? html`<ul class="post-items">${post.items.map((i) => html`<li>${i}</li>`)}</ul>` : ''}
        <p class="why">${post.why}</p>`;
    default:
      return html`<h3>${post.title}</h3>`;
  }
}

export function postCard(post, config) {
  return html`<article class="post post-${post.type}" id="${post.id}">
    <div class="post-when">${time(post.at, config)}<span>${LABEL[post.type] ?? ''}</span></div>
    <div class="post-body">${postBody(post, config)}</div>
  </article>`;
}

export function streamList(posts, config) {
  const sorted = [...posts].sort((a, b) => b.at.localeCompare(a.at));
  if (!sorted.length) {
    return html`<p class="empty">Nothing yet for this day. New stories appear here automatically every few minutes.</p>`;
  }
  return sorted.map((post) => postCard(post, config));
}

export function eventRow(event, config) {
  return html`<li class="event">
    <span class="event-when">${time(event.at, config, 'dhm')}</span>
    <span class="event-name">${event.name}${event.heat >= 3 ? html` <span class="heat heat-high">High impact</span>` : html` <span class="heat heat-medium">Medium impact</span>`}</span>
    ${event.forecast || event.previous ? html`<span class="event-nums">${event.forecast ? `Expected ${event.forecast}` : ''}${event.forecast && event.previous ? ', ' : ''}${event.previous ? `last time ${event.previous}` : ''}</span>` : ''}
  </li>`;
}

export function joinBox(config, heading = 'Get each big gold story on your phone') {
  return html`<section class="side-box">
    <h2>${heading}</h2>
    <p>A reminder before each big US release, and the reason behind each big move as it happens. Free, with no sign-up.</p>
    <div class="buttons">
      ${config.telegramUrl ? html`<a class="btn btn-gold" href="${config.telegramUrl}" rel="noopener">Join on Telegram</a>` : ''}
      <a class="btn" href="/gold-news-calendar">Add the free calendar</a>
    </div>
  </section>`;
}
