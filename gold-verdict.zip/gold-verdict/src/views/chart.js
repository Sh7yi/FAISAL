import { html, raw, esc } from '../lib/html.js';
import { tradingWindow } from '../lib/time.js';
import { money } from '../lib/format.js';
import { stamp } from './components.js';

const VIEW_W = 1000;
const VIEW_H = 300;

function niceStep(range, target = 4) {
  const rough = range / target;
  const mag = 10 ** Math.floor(Math.log10(rough));
  for (const mult of [1, 2, 2.5, 5, 10]) if (mult * mag >= rough) return mult * mag;
  return 10 * mag;
}

// Breaks the line where data is missing, rather than drawing a straight bridge over the gap.
function buildPath(points, x, y, maxGap) {
  let line = '';
  let prev = null;
  for (const pt of points) {
    line += `${prev === null || pt.t - prev > maxGap ? 'M' : 'L'}${x(pt.t).toFixed(1)} ${y(pt.p).toFixed(1)}`;
    prev = pt.t;
  }
  return line;
}

const pctOf = (value, total) => `${((value / total) * 100).toFixed(2)}%`;

// A plain line chart that stays sharp at any width: the line is SVG and the labels are HTML.
function plot({ points, startT, endT, ticksX, pins = [], reference, ariaLabel, className = '', maxGap = 18e5 }) {
  const prices = points.map((p) => p.p);
  if (reference) prices.push(reference.value);
  let low = Math.min(...prices);
  let high = Math.max(...prices);
  const spare = Math.max((high - low) * 0.12, high * 0.0008);
  low -= spare;
  high += spare;
  const step = niceStep(high - low);
  const x = (t) => ((t - startT) / (endT - startT)) * VIEW_W;
  const y = (p) => VIEW_H - ((p - low) / (high - low)) * VIEW_H;
  const line = buildPath(points, x, y, maxGap);
  const last = points.at(-1);
  const first = points[0];
  const area = `${buildPath(points, x, y, Infinity)}L${x(last.t).toFixed(1)} ${VIEW_H}L${x(first.t).toFixed(1)} ${VIEW_H}Z`;
  const ticksY = [];
  for (let v = Math.ceil(low / step) * step; v <= high; v += step) ticksY.push(v);
  const compact = points.map((p) => [p.t, p.p]);

  return html`<div class="plot ${className}" role="group" aria-label="${ariaLabel}" data-points="${JSON.stringify(compact)}" data-start="${startT}" data-end="${endT}">
    <svg viewBox="0 0 ${VIEW_W} ${VIEW_H}" preserveAspectRatio="none" aria-hidden="true">
      ${ticksY.map((v) => raw(`<line class="grid" x1="0" x2="${VIEW_W}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" vector-effect="non-scaling-stroke"/>`))}
      ${reference ? raw(`<line class="ref" x1="0" x2="${VIEW_W}" y1="${y(reference.value).toFixed(1)}" y2="${y(reference.value).toFixed(1)}" vector-effect="non-scaling-stroke"/>`) : ''}
      <path class="area" d="${area}"/>
      <path class="line" d="${line}" vector-effect="non-scaling-stroke"/>
    </svg>
    ${ticksY.map((v) => html`<span class="tick-y" style="top:${pctOf(y(v), VIEW_H)}">${money(v)}</span>`)}
    ${reference ? html`<span class="ref-label" style="top:${pctOf(y(reference.value), VIEW_H)}">${reference.label}</span>` : ''}
    ${ticksX.map((tick) => html`<span class="tick-x" style="left:${pctOf(x(tick.t), VIEW_W)}">${tick.node}</span>`)}
    <span class="end-dot" style="left:${pctOf(x(last.t), VIEW_W)};top:${pctOf(y(last.p), VIEW_H)}"></span>
    ${pins.map((pin) => html`<a class="pin" href="#${pin.id}" style="left:${pctOf(x(pin.t), VIEW_W)};top:${pctOf(y(pin.p), VIEW_H)}" title="${pin.title}" aria-label="${pin.title}">${stamp(pin.verdict)}</a>`)}
    <div class="cross" hidden></div>
    <div class="tip" hidden></div>
  </div>`;
}

// Today's line, with each big story pinned to the moment it landed.
export function dayChart(day, baseline) {
  const raw_ = (day?.snapshots ?? []).map((s) => ({ t: new Date(s.t).getTime(), p: s.p })).sort((a, b) => a.t - b.t);
  if (raw_.length < 3) return '';
  const { start, end } = tradingWindow(day.date);
  const startT = start.getTime();
  const endT = end.getTime();
  const points = raw_.filter((p) => p.t >= startT && p.t <= endT);
  if (points.length < 3) return '';

  const ticksX = [];
  for (let t = startT + 36e5 * 2; t < endT; t += 36e5 * 4) {
    const iso = new Date(t).toISOString();
    ticksX.push({ t, node: html`<time data-time="${iso}" data-fmt="hm" datetime="${iso}">${iso.slice(11, 16)}</time>` });
  }

  const pins = (day.posts ?? [])
    .filter((p) => (p.type === 'news' || p.type === 'developing') && p.verdict && p.importance !== 'low')
    .map((p) => {
      const t = new Date(p.at).getTime();
      if (t < points[0].t || t > endT) return null;
      const near = points.reduce((best, pt) => (Math.abs(pt.t - t) < Math.abs(best.t - t) ? pt : best), points[0]);
      if (Math.abs(near.t - t) > 36e5) return null;
      return { id: p.id, t, p: near.p, verdict: p.verdict, title: `${p.verdict}: ${p.title}` };
    })
    .filter(Boolean);

  const lo = Math.min(...points.map((p) => p.p));
  const hi = Math.max(...points.map((p) => p.p));
  return html`<figure class="daychart">
    <figcaption>Gold today, with each big story marked where it landed</figcaption>
    ${plot({
      points, startT, endT, ticksX, pins,
      reference: baseline ? { value: baseline, label: `Last close ${money(baseline)}` } : null,
      ariaLabel: `Gold price so far today, between ${money(lo)} and ${money(hi)}, now ${money(points.at(-1).p)}. Each story is listed below.`,
    })}
  </figure>`;
}

// The longer view for the price history page.
export function historyChart(closes) {
  const points = Object.entries(closes)
    .map(([date, p]) => ({ t: Date.parse(`${date}T12:00:00Z`), p, date }))
    .sort((a, b) => a.t - b.t);
  if (points.length < 3) return '';
  const startT = points[0].t;
  const endT = points.at(-1).t;
  const longSpan = endT - startT > 150 * 864e5;
  const label = new Intl.DateTimeFormat('en-GB', longSpan ? { month: 'short', year: 'numeric', timeZone: 'UTC' } : { day: 'numeric', month: 'short', timeZone: 'UTC' });
  const ticksX = [0.08, 0.36, 0.64, 0.92].map((share) => {
    const t = startT + share * (endT - startT);
    return { t, node: label.format(t) };
  });
  return plot({
    points: points.map(({ t, p }) => ({ t, p })), startT, endT, ticksX, className: 'plot-history', maxGap: 10 * 864e5,
    ariaLabel: `Gold closing prices from ${esc(points[0].date)} to ${esc(points.at(-1).date)}. The same numbers are in the table below.`,
  });
}
