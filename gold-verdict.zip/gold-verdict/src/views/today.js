import { html, raw } from '../lib/html.js';
import { heroModel } from '../core/hero.js';
import { changes, topStories } from '../core/state.js';
import { shortDate, longDate } from '../lib/time.js';
import { money, pct } from '../lib/format.js';
import { dayChart } from './chart.js';
import { eventRow, joinBox, streamList, stamp } from './components.js';
import { layout } from './layout.js';
import { GUIDES } from '../content/guides.js';

const QUICK_CURRENCIES = ['USD', 'AED', 'GBP', 'EUR'];

function changeRow(label, key, change) {
  const c = change[key];
  const dir = !c ? 'none' : c.pct > 0.005 ? 'up' : c.pct < -0.005 ? 'down' : 'flat';
  return html`<div class="change change-${dir}" data-change="${key}">
    <dt>${label}</dt>
    <dd><span class="change-abs" data-part="abs">${c ? `${c.abs >= 0 ? '+' : '−'}${money(Math.abs(c.abs))}` : ''}</span><span class="change-pct" data-part="pct">${c ? pct(c.pct) : 'Builds with time'}</span></dd>
  </div>`;
}

export function ingot(state, config, { compact = false } = {}) {
  const change = changes(state);
  const price = state.price?.usd;
  const quick = [...new Set(['USD', config.localCurrency, ...QUICK_CURRENCIES])].slice(0, 4);
  const others = Object.keys(state.fx.rates).filter((c) => !quick.includes(c)).sort();
  return html`<section class="price-panel ${compact ? 'price-panel-compact' : ''}" aria-label="Gold price now">
    <div class="ingot">
      <div class="ingot-face">
        <p class="ingot-label">Spot gold, one troy ounce</p>
        <p class="ingot-price" data-price aria-live="off">${price ? money(price, 'USD', 2) : 'Loading'}</p>
        <p class="ingot-state" data-price-state>${state.price?.at ? 'Delayed a few minutes until the live feed connects' : 'Waiting for the first price'}</p>
      </div>
    </div>
    <div class="currency" role="group" aria-label="Choose a currency">
      ${quick.map((c, i) => html`<button type="button" data-currency="${c}" aria-pressed="${i === 0 ? 'true' : 'false'}">${c}</button>`)}
      <label class="currency-more"><span class="sr">More currencies</span>
        <select data-currency-more>
          <option value="">More</option>
          ${others.map((c) => html`<option value="${c}">${c}</option>`)}
        </select>
      </label>
    </div>
    <dl class="changes">
      ${changeRow('Today', 'day', change)}
      ${changeRow('This week', 'week', change)}
      ${changeRow('This month', 'month', change)}
      ${changeRow('This year', 'year', change)}
    </dl>
    <p class="price-note">Spot price, for information only and not for trading. It may be delayed.</p>
  </section>`;
}

function statusLine(model, config) {
  if (model.status.open) return html`<span class="market market-open">Market open</span>`;
  const iso = model.status.opensAt.toISOString();
  return html`<span class="market market-closed">Market closed, reopens <time data-time="${iso}" data-fmt="dhm" datetime="${iso}">${iso.slice(11, 16)} UTC</time></span>`;
}

export function heroText(model) {
  return html`<p class="hero-answer" data-hero-price>${model.priceLine}</p>
    <p class="hero-story">${model.storyLine} ${model.whyLine}</p>`;
}

export function movedList(state, now) {
  const model = heroModel(state, now);
  const direction = model.status.open && (model.dir === 'up' || model.dir === 'down') ? model.dir : null;
  const stories = topStories(state.today, 3, direction);
  if (direction) {
    const opposite = direction === 'up' ? 'bearish' : 'bullish';
    const against = topStories(state.today, 20).find((s) => s.verdict === opposite && s.importance === 'high');
    if (against && !stories.includes(against)) stories.splice(2, 1, against);
  }
  if (!stories.length) return html`<p class="empty">Nothing has stood out yet today.</p>`;
  return html`<ol class="moved">${stories.map((s) => html`<li class="moved-${s.verdict}">
    ${stamp(s.verdict)}
    <a href="#${s.id}">${s.title}</a>
    <span class="moved-verdict">${s.verdict === 'mixed' ? 'Mixed' : s.verdict === 'bullish' ? 'Bullish' : 'Bearish'}</span>
  </li>`)}</ol>`;
}

export function comingUp(state, config, now) {
  const nowIso = now.toISOString();
  const events = state.calendar.events.filter((e) => e.at > nowIso).slice(0, 5);
  if (!events.length) return html`<p class="empty">No big US releases are left on this week's calendar.</p>`;
  return html`<ul class="events">${events.map((e) => eventRow(e, config))}</ul>`;
}

export function todayFragment(state, config, now) {
  const model = heroModel(state, now);
  const c = changes(state);
  return {
    updatedAt: state.lastTickAt,
    date: state.today?.date ?? null,
    base: { day: c.day?.base ?? null, week: c.week?.base ?? null, month: c.month?.base ?? null, year: c.year?.base ?? null },
    price: state.price?.usd ?? null,
    question: model.question,
    hero: heroText(model).toString(),
    moved: movedList(state, now).toString(),
    stream: html`${streamList(state.today.posts, config)}`.toString(),
    coming: comingUp(state, config, now).toString(),
    chart: html`${dayChart(state.today, changes(state).day?.base)}`.toString(),
  };
}

export function todayPage({ state, config, now, path }) {
  const model = heroModel(state, now);
  const dateShort = state.today?.date ? shortDate(state.today.date) : '';
  const description = [model.priceLine, model.top ? `The main gold news today: ${model.top.title}` : ''].filter(Boolean).join(' ').slice(0, 155);
  const stale = state.lastTickAt && now - new Date(state.lastTickAt) > 30 * 60000;
  const earlier = state.days.slice(0, 8);

  const body = html`
  <section class="hero">
    <div class="wrap hero-grid">
      <div class="hero-main">
        <p class="hero-date"><span>${model.dateLabel}</span>${statusLine(model, config)}</p>
        <h1 data-question>${model.question}</h1>
        <div data-hero>${heroText(model)}</div>
        ${stale ? html`<p class="stale">Updates have paused. The last check was at ${new Date(state.lastTickAt).toISOString().slice(11, 16)} UTC, so this may be out of date.</p>` : ''}
      </div>
      ${ingot(state, config)}
    </div>
    <div class="wrap" data-chart>${dayChart(state.today, changes(state).day?.base)}</div>
  </section>

  <div class="wrap columns">
    <div class="col-main">
      <section class="section-moved">
        <h2>What moved it</h2>
        <div data-moved>${movedList(state, now)}</div>
        <p class="note">Each verdict is the textbook reading of the story: what it usually means for gold. Gold does not always follow it. <a href="/guides/priced-in">Why gold sometimes goes the other way</a>.</p>
      </section>

      <section class="section-stream">
        <h2>Today's gold news, newest first</h2>
        <p class="note">Times are shown in your own time zone. This page updates by itself every few minutes.</p>
        <div class="stream" data-stream>${streamList(state.today.posts, config)}</div>
      </section>

      ${earlier.length ? html`<section class="section-earlier">
        <h2>Earlier days</h2>
        <ul class="days">${earlier.map((d) => html`<li><a href="/gold-today/${d.date}"><b>${shortDate(d.date)}</b> <span>${d.title}</span></a></li>`)}</ul>
        <p><a href="/gold-today">See all days</a></p>
      </section>` : ''}
    </div>

    <aside class="col-side">
      <section class="side-box">
        <h2>Coming up</h2>
        <div data-coming>${comingUp(state, config, now)}</div>
        <p><a href="/gold-news-calendar">See the full calendar</a></p>
      </section>
      ${joinBox(config)}
      <section class="side-box">
        <h2>Learn the why</h2>
        <ul class="plain-links">${GUIDES.slice(0, 5).map((g) => html`<li><a href="/guides/${g.slug}">${g.title}</a></li>`)}</ul>
      </section>
    </aside>
  </div>`;

  return layout({
    config, state, path: '/why-is-gold-moving-today', active: '/why-is-gold-moving-today',
    title: `${model.titleTag} What moved it, ${dateShort}`,
    description, body,
  });
}

export function dayPage({ day, state, config }) {
  const closePost = day.posts.find((p) => p.type === 'close');
  const body = html`
  <section class="page-head"><div class="wrap">
    <p class="crumb"><a href="/gold-today">All days</a></p>
    <h1>What moved gold on ${longDate(day.date)}</h1>
    ${closePost ? html`<p class="lede">${closePost.title}. ${closePost.why ?? ''}</p>` : ''}
  </div></section>
  <div class="wrap narrow">
    ${dayChart(day, null)}
    <div class="stream">${streamList(day.posts, config)}</div>
  </div>`;
  return layout({
    config, state, path: `/gold-today/${day.date}`,
    title: `What moved gold on ${shortDate(day.date)}`,
    description: closePost ? closePost.title : `Gold news and what it meant, ${longDate(day.date)}.`,
    body, active: '/why-is-gold-moving-today',
  });
}

export function archivePage({ state, config }) {
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>What moved gold, day by day</h1>
    <p class="lede">Each day's stories and verdicts, kept as they were published.</p>
  </div></section>
  <div class="wrap narrow">
    ${state.days.length
      ? html`<ul class="days">${state.days.map((d) => html`<li><a href="/gold-today/${d.date}"><b>${shortDate(d.date)}</b> <span>${d.title}</span></a></li>`)}</ul>`
      : html`<p class="empty">The first day is added here after gold's first close, at 5pm New York time.</p>`}
  </div>`;
  return layout({ config, state, path: '/gold-today', title: 'What moved gold, day by day', description: 'An archive of what moved gold each day, with the news and what it meant.', body });
}
