import { html } from '../lib/html.js';
import { layout } from './layout.js';
import { eventRow, time } from './components.js';
import { historyChart } from './chart.js';
import { ingot } from './today.js';
import { lastCloseBefore } from '../core/state.js';
import { readingOf } from '../collector/calendar.js';
import { FRED_SERIES, METALS } from '../collector/index.js';
import { GUIDES, guideBySlug } from '../content/guides.js';
import { dateInZone, longDate, marketStatus, shortDate } from '../lib/time.js';
import { money, pct } from '../lib/format.js';

const OZ_G = 31.1034768;
const TOLA_G = 11.6638038;
const KARATS = [[24, 'Pure gold, 999'], [22, '916, common for jewellery in the Gulf and India'], [21, '875, common in the Gulf and Middle East'], [18, '750'], [14, '585'], [9, '375']];

export const COUNTRIES = [
  { slug: 'uae', name: 'the UAE', currency: 'AED', note: 'The dirham is pegged to the US dollar.' },
  { slug: 'saudi-arabia', name: 'Saudi Arabia', currency: 'SAR', note: 'The riyal is pegged to the US dollar.' },
  { slug: 'qatar', name: 'Qatar', currency: 'QAR', note: 'The riyal is pegged to the US dollar.' },
  { slug: 'kuwait', name: 'Kuwait', currency: 'KWD', note: '' },
  { slug: 'oman', name: 'Oman', currency: 'OMR', note: 'The rial is pegged to the US dollar.' },
  { slug: 'bahrain', name: 'Bahrain', currency: 'BHD', note: 'The dinar is pegged to the US dollar.' },
  { slug: 'india', name: 'India', currency: 'INR', note: 'Shop prices also include import duty and tax.' },
  { slug: 'pakistan', name: 'Pakistan', currency: 'PKR', note: '' },
  { slug: 'egypt', name: 'Egypt', currency: 'EGP', note: '' },
  { slug: 'turkey', name: 'Turkey', currency: 'TRY', note: '' },
  { slug: 'uk', name: 'the UK', currency: 'GBP', note: '' },
  { slug: 'usa', name: 'the USA', currency: 'USD', note: '' },
  { slug: 'eurozone', name: 'the euro zone', currency: 'EUR', note: '' },
  { slug: 'canada', name: 'Canada', currency: 'CAD', note: '' },
  { slug: 'australia', name: 'Australia', currency: 'AUD', note: '' },
  { slug: 'singapore', name: 'Singapore', currency: 'SGD', note: '' },
  { slug: 'malaysia', name: 'Malaysia', currency: 'MYR', note: '' },
  { slug: 'south-africa', name: 'South Africa', currency: 'ZAR', note: '' },
];

export function calendarPage({ state, config, now }) {
  const nowIso = now.toISOString();
  const upcoming = state.calendar.events.filter((e) => e.at > nowIso);
  const groups = new Map();
  for (const e of upcoming) {
    const key = dateInZone(new Date(e.at), config.timeZone);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(e);
  }
  const host = config.siteUrl ? config.siteUrl.replace(/^https?:\/\//, '') : '';
  const webcal = host ? `webcal://${host}/gold-calendar.ics` : '/gold-calendar.ics';
  const google = host ? `https://calendar.google.com/calendar/r?cid=${encodeURIComponent(webcal)}` : '';
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>The news that moves gold, and when it lands</h1>
    <p class="lede">The US releases that matter most to gold this week. Add them to your phone and get a reminder 15 minutes before each one.</p>
    <div class="buttons">
      <a class="btn btn-gold" href="${webcal}">Add to iPhone or Mac</a>
      ${google ? html`<a class="btn btn-on-dark" href="${google}" rel="noopener">Add to Google Calendar</a>` : ''}
      <a class="btn btn-on-dark" href="/gold-calendar.ics">Download for Outlook</a>
    </div>
  </div></section>
  <div class="wrap narrow">
    <p class="note">Times are shown in your own time zone.</p>
    ${upcoming.length
      ? [...groups.entries()].map(([date, events]) => html`<section class="cal-day"><h2>${longDate(date)}</h2>
          <ul class="events">${events.map((e) => html`${eventRow(e, config)}<li class="event-reading">${readingOf(e)}</li>`)}</ul></section>`)
      : html`<p class="empty">No big US releases are left this week. Next week's calendar appears on Sunday.</p>`}
  </div>`;
  return layout({ config, state, path: '/gold-news-calendar', active: '/gold-news-calendar', title: 'Gold news calendar', description: 'The US data releases and Fed events that move gold this week, in your own time zone, with free phone reminders.', body });
}

export function calculatorPage({ state, config }) {
  const currencies = Object.keys(state.fx.rates).sort();
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>What is your gold worth?</h1>
    <p class="lede">Enter a weight and purity to see the value at today's spot price. Shops usually add a making charge when selling and pay less than spot when buying.</p>
  </div></section>
  <div class="wrap narrow">
    <form class="calc" data-calc>
      <label>Weight <input type="number" name="weight" min="0" step="any" value="10" inputmode="decimal"></label>
      <label>Unit
        <select name="unit">
          <option value="1">Grams</option>
          <option value="${TOLA_G}">Tola (11.66 g)</option>
          <option value="${OZ_G}">Troy ounces</option>
          <option value="1000">Kilograms</option>
        </select>
      </label>
      <label>Purity
        <select name="karat">${KARATS.map(([k], i) => html`<option value="${k}" ${i === 1 ? 'selected' : ''}>${k} karat</option>`)}</select>
      </label>
      <label>Currency
        <select name="currency">${currencies.map((c) => html`<option value="${c}" ${c === config.localCurrency ? 'selected' : ''}>${c}</option>`)}</select>
      </label>
      <label>Making charge, optional (%) <input type="number" name="making" min="0" step="any" value="0" inputmode="decimal"></label>
    </form>
    <div class="calc-result" aria-live="polite">
      <p class="calc-label">Value at spot</p>
      <p class="calc-value" data-calc-value>–</p>
      <p class="calc-detail" data-calc-detail></p>
    </div>
    <p class="note">For information only. Based on the indicative spot price and exchange rates, which may be delayed. Check the real price with your dealer.</p>
  </div>`;
  return layout({ config, state, path: '/gold-calculator', active: '/gold-calculator', title: 'Gold calculator', description: 'Work out what your gold is worth by weight and karat, in grams, tola or ounces, in your own currency.', body });
}

function rateTable(state, currency) {
  const fx = state.fx.rates[currency] ?? null;
  const usd = state.price?.usd ?? null;
  const cell = (factor) => (usd && fx ? (usd * fx * factor).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '–');
  return html`<div class="table-wrap"><table class="rates">
    <caption>Prices in ${currency}</caption>
    <thead><tr><th scope="col">Purity</th><th scope="col">Per gram</th><th scope="col">Per tola</th><th scope="col">Per ounce</th></tr></thead>
    <tbody>${KARATS.map(([k, note]) => {
      const purity = k / 24;
      const live = (grams) => html`data-live="${(purity * grams) / OZ_G}" data-cur="${currency}"`;
      return html`<tr><th scope="row">${k} karat <small>${note}</small></th>
        <td ${live(1)}>${cell((purity * 1) / OZ_G)}</td>
        <td ${live(TOLA_G)}>${cell((purity * TOLA_G) / OZ_G)}</td>
        <td ${live(OZ_G)}>${cell(purity)}</td></tr>`;
    })}</tbody>
  </table></div>`;
}

export function ratePage({ state, config }) {
  const home = COUNTRIES.find((c) => c.currency === config.localCurrency) ?? COUNTRIES[0];
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>Gold price today</h1>
    <p class="lede">The spot price of gold, converted to your currency and broken down by purity. Shop prices are higher because they add making charges and any local tax.</p>
  </div></section>
  <div class="wrap columns">
    <div class="col-main">
      <h2>Gold rate in ${home.name} (${home.currency})</h2>
      ${rateTable(state, home.currency)}
      <h2>Gold rate by country</h2>
      <ul class="country-list">${COUNTRIES.map((c) => html`<li><a href="/gold-rate/${c.slug}">Gold rate in ${c.name}</a></li>`)}</ul>
    </div>
    <aside class="col-side">${ingot(state, config, { compact: true })}</aside>
  </div>`;
  return layout({ config, state, path: '/gold-rate', active: '/gold-rate', title: 'Gold price today by country and karat', description: 'Today\'s gold price per gram, tola and ounce for 24, 22, 21 and 18 karat, in your own currency.', body });
}

export function countryPage({ state, config, country }) {
  const body = html`
  <section class="page-head"><div class="wrap">
    <p class="crumb"><a href="/gold-rate">All countries</a></p>
    <h1>Gold rate in ${country.name} today</h1>
    <p class="lede">Spot value in ${country.currency}. ${country.note} Shop prices are higher because they add making charges and any local tax.</p>
  </div></section>
  <div class="wrap narrow">
    ${rateTable(state, country.currency)}
    <p class="note">For information only. Based on the indicative spot price and exchange rates, which may be delayed.</p>
    <p><a href="/why-is-gold-moving-today">See why gold is moving today</a></p>
  </div>`;
  return layout({ config, state, path: `/gold-rate/${country.slug}`, active: '/gold-rate', title: `Gold rate in ${country.name} today (${country.currency})`, description: `Today's gold rate in ${country.name} per gram, tola and ounce, for 24, 22, 21 and 18 karat.`, body });
}

const MARKET_READINGS = {
  XAG: 'Silver usually moves with gold, but in bigger swings.',
  XPT: 'Platinum is driven more by industry and car makers.',
  XPD: 'Palladium is driven mostly by car makers.',
  HG: 'Copper tracks the health of the world economy.',
  BTC: 'Bitcoin trades more like a risky asset than like gold.',
  ETH: 'Ethereum tends to follow bitcoin.',
  DGS10: 'When this rises, gold usually falls. Bonds pay more, and gold pays nothing.',
  DTWEXBGS: 'When this rises, gold usually falls. Gold is priced in dollars.',
  DCOILBRENTEU: 'More expensive oil can keep inflation and US rates high, which usually hurts gold.',
};

export function marketsPage({ state, config }) {
  const today = state.today.date;
  const goldBase = lastCloseBefore(state.closes.XAU, today);
  const row = (name, price, base, reading, digits = 2) => {
    const change = price && base ? ((price - base.value) / base.value) * 100 : null;
    return html`<tr><th scope="row">${name}<small>${reading}</small></th><td>${price ? money(price, 'USD', digits) : '–'}</td>
      <td class="${change === null || Math.abs(change) < 0.005 ? '' : change > 0 ? 'num-up' : 'num-down'}">${change === null ? 'Builds with time' : pct(change)}</td></tr>`;
  };
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>Gold and other markets</h1>
    <p class="lede">Gold rarely moves alone. These are the markets traders watch next to it, and what each one usually means.</p>
  </div></section>
  <div class="wrap narrow">
    <h2>Metals and crypto, today</h2>
    <div class="table-wrap"><table>
      <thead><tr><th scope="col">Market</th><th scope="col">Price (USD)</th><th scope="col">Today</th></tr></thead>
      <tbody>
        ${row('Gold', state.price?.usd, goldBase, 'The one this site is about.')}
        ${METALS.map((m) => row(m.name, state.metals[m.symbol]?.price, lastCloseBefore(state.closes[m.symbol], today), MARKET_READINGS[m.symbol]))}
      </tbody>
    </table></div>
    <h2>What drives gold</h2>
    <p class="note">These come from official US data, published with a delay of a day or more.</p>
    <div class="table-wrap"><table>
      <thead><tr><th scope="col">Measure</th><th scope="col">Latest</th><th scope="col">Change</th><th scope="col">As of</th></tr></thead>
      <tbody>${FRED_SERIES.map((s) => {
        const d = state.rates.series[s.id];
        if (!d) return html`<tr><th scope="row">${s.name}<small>${MARKET_READINGS[s.id]}</small></th><td colspan="3">Waiting for data</td></tr>`;
        const delta = d.prev === null ? null : d.value - d.prev;
        const shown = s.unit === '$' ? money(d.value, 'USD', 2) : `${d.value.toFixed(2)}${s.unit}`;
        return html`<tr><th scope="row">${s.name}<small>${MARKET_READINGS[s.id]}</small></th><td>${shown}</td>
          <td>${delta === null ? '–' : `${delta >= 0 ? '+' : '−'}${Math.abs(delta).toFixed(2)}`}</td><td>${shortDate(d.date)}</td></tr>`;
      })}</tbody>
    </table></div>
  </div>`;
  return layout({ config, state, path: '/markets', active: '/markets', title: 'Gold and other markets', description: 'Gold next to silver, oil, the dollar and bond yields, and what each one usually means for gold.', body });
}

export function historyPage({ state, config }) {
  const closes = state.closes.XAU;
  const rows = Object.entries(closes).sort((a, b) => b[0].localeCompare(a[0]));
  const chart = historyChart(closes);
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>Gold price history</h1>
    <p class="lede">Gold's daily close, recorded at 5pm New York time.</p>
  </div></section>
  <div class="wrap narrow">
    ${chart ? html`<figure class="daychart daychart-light"><figcaption>Gold, US dollars per ounce</figcaption>${chart}</figure>` : html`<p class="empty">This chart fills in from the day the site goes live, one close at a time.</p>`}
    ${rows.length ? html`<h2>Daily closes</h2><div class="table-wrap"><table>
      <thead><tr><th scope="col">Date</th><th scope="col">Close</th><th scope="col">Change</th></tr></thead>
      <tbody>${rows.slice(0, 60).map(([date, value], i) => {
        const prev = rows[i + 1]?.[1];
        const change = prev ? ((value - prev) / prev) * 100 : null;
        return html`<tr><th scope="row"><a href="/gold-today/${date}">${longDate(date)}</a></th><td>${money(value, 'USD', 2)}</td><td class="${change === null ? '' : change >= 0 ? 'num-up' : 'num-down'}">${change === null ? '–' : pct(change)}</td></tr>`;
      })}</tbody></table></div>` : ''}
  </div>`;
  return layout({ config, state, path: '/gold-price-history', title: 'Gold price history', description: 'Daily closing prices for gold, with a link to what moved it each day.', body });
}

export function guidesIndex({ state, config }) {
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>Gold School</h1>
    <p class="lede">Short lessons on what moves gold and why, with no jargon. Each takes a couple of minutes.</p>
  </div></section>
  <div class="wrap narrow">
    <ul class="guide-list">${GUIDES.map((g) => html`<li><a href="/guides/${g.slug}"><b>${g.title}</b><span>${g.summary}</span></a></li>`)}</ul>
  </div>`;
  return layout({ config, state, path: '/guides/', active: '/guides/', title: 'Gold School', description: 'Short, plain-English lessons on what moves the gold price and why.', body });
}

export function guidePage({ state, config, slug }) {
  const guide = guideBySlug(slug);
  if (!guide) return null;
  const blocks = guide.body.map(([kind, content]) => {
    if (kind === 'h2') return html`<h2>${content}</h2>`;
    if (kind === 'ul') return html`<ul>${content.map((li) => html`<li>${li}</li>`)}</ul>`;
    return html`<p>${content}</p>`;
  });
  const others = GUIDES.filter((g) => g.slug !== slug).slice(0, 4);
  const body = html`
  <section class="page-head"><div class="wrap">
    <p class="crumb"><a href="/guides/">Gold School</a></p>
    <h1>${guide.title}</h1>
    <p class="lede">${guide.summary}</p>
  </div></section>
  <div class="wrap narrow prose">${blocks}
    <h2>Keep reading</h2>
    <ul>${others.map((g) => html`<li><a href="/guides/${g.slug}">${g.title}</a></li>`)}</ul>
  </div>`;
  return layout({ config, state, path: `/guides/${slug}`, active: '/guides/', title: guide.title, description: guide.summary, body });
}

export function marketHoursPage({ state, config, now }) {
  const status = marketStatus(now);
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>When does gold trade?</h1>
    <p class="lede">Gold trades almost around the clock, from Sunday evening to Friday evening New York time.</p>
  </div></section>
  <div class="wrap narrow prose">
    <p><strong>Right now the market is ${status.open ? 'open' : 'closed'}.</strong>
      ${status.open ? html`Today's session ends at ${time(status.closesAt.toISOString(), config, 'dhm')}, your time.` : html`It reopens at ${time(status.opensAt.toISOString(), config, 'dhm')}, your time.`}</p>
    <h2>The weekly pattern</h2>
    <ul>
      <li>Opens Sunday at 6pm New York time.</li>
      <li>Closes Friday at 5pm New York time.</li>
      <li>Pauses for one hour each weekday, from 5pm to 6pm New York time.</li>
    </ul>
    <p>Trading may also stop early around major holidays, which this site does not track.</p>
    <h2>The busiest hours</h2>
    <p>Gold is most active when London and New York are both open, from 8am to noon New York time. Most big US data lands at 8:30am or 10am New York time, inside that window.</p>
    <h2>Why "today" starts at 5pm</h2>
    <p>Gold's day runs from 5pm to 5pm New York time, so this site's daily change uses the 5pm close, and a new gold day can begin while it is still yesterday evening in New York.</p>
  </div>`;
  return layout({ config, state, path: '/gold-market-hours', title: 'Gold market hours', description: 'When gold trades, shown in your own time zone, and the busiest hours of the day.', body });
}

const SHEET = [
  ['US inflation above forecast', 'bearish', 'Higher interest rates become more likely.'],
  ['US inflation below forecast', 'bullish', 'Lower interest rates become more likely.'],
  ['More US jobs than forecast', 'bearish', 'The Fed has room to keep rates high.'],
  ['Fewer US jobs than forecast', 'bullish', 'Lower rates become more likely.'],
  ['Fed raises rates or sounds hawkish', 'bearish', 'Bonds and savings pay more than gold.'],
  ['Fed cuts rates or sounds dovish', 'bullish', 'Gold costs less to hold, and the dollar often falls.'],
  ['The dollar rises', 'bearish', 'Gold gets more expensive for buyers outside the US.'],
  ['The dollar falls', 'bullish', 'Gold gets cheaper for buyers outside the US.'],
  ['US bond yields rise', 'bearish', 'Bonds become a stronger rival to gold.'],
  ['US bond yields fall', 'bullish', 'Holding gold costs less in lost income.'],
  ['Oil shock', 'bearish', 'More expensive oil keeps inflation and rates high.'],
  ['War or crisis with no oil angle', 'bullish', 'Nervous investors buy gold for protection.'],
  ['War in an oil region', 'mixed', 'Fear helps gold, but more expensive oil hurts it.'],
  ['Central banks buying gold', 'bullish', 'A steady source of demand.'],
  ['Stock market crash', 'mixed', 'Safety buying helps, but forced selling hurts.'],
];

export function cheatSheetPage({ state, config }) {
  const word = { bullish: 'Usually good', bearish: 'Usually bad', mixed: 'Could go either way' };
  const body = html`
  <section class="page-head"><div class="wrap">
    <h1>The gold cheat sheet</h1>
    <p class="lede">The usual reaction to the news that matters most. Gold does not always follow it.</p>
  </div></section>
  <div class="wrap narrow">
    <div class="table-wrap"><table class="sheet">
      <thead><tr><th scope="col">When this happens</th><th scope="col">For gold</th><th scope="col">Why</th></tr></thead>
      <tbody>${SHEET.map(([what, verdict, why]) => html`<tr><th scope="row">${what}</th><td class="sheet-${verdict}">${word[verdict]}</td><td>${why}</td></tr>`)}</tbody>
    </table></div>
    <p><a href="/guides/priced-in">Why gold sometimes goes the other way</a></p>
  </div>`;
  return layout({ config, state, path: '/gold-cheat-sheet', title: 'The gold cheat sheet', description: 'A one-page guide to how gold usually reacts to inflation, jobs, the Fed, the dollar, war and oil.', body });
}

function simplePage({ state, config, path, title, description, paragraphs }) {
  const body = html`
  <section class="page-head"><div class="wrap"><h1>${title}</h1></div></section>
  <div class="wrap narrow prose">${paragraphs.map(([kind, text]) => (kind === 'h2' ? html`<h2>${text}</h2>` : html`<p>${text}</p>`))}</div>`;
  return layout({ config, state, path, title, description, body });
}

export const aboutPage = ({ state, config }) => simplePage({
  state, config, path: '/about', title: `About ${config.name}`, description: `What ${config.name} is and how it works.`,
  paragraphs: [
    ['p', `Gold moves and the headlines rarely explain why in words most people can use. ${config.name} does one job: it answers "why is gold moving today?" in plain English.`],
    ['h2', 'How it works'],
    ['p', 'Every few minutes the site checks the gold price and a set of news feeds. When a story could matter for gold, it is given a verdict: bullish, bearish or mixed. That verdict is the textbook reading of the news, along with a one-line reason.'],
    ['p', 'The verdicts are produced automatically and can be wrong. They describe what the news usually means, not what gold will do.'],
    ['h2', 'Where the data comes from'],
    ['p', 'Gold and other prices come from gold-api.com. Exchange rates come from ExchangeRate-API. Economic release dates come from the Forex Factory calendar. Yields, the dollar index and oil come from the Federal Reserve Bank of St. Louis (FRED). Headlines come from the publishers\' public news feeds and link back to them.'],
  ],
});

export const disclaimerPage = ({ state, config }) => simplePage({
  state, config, path: '/disclaimer', title: 'Disclaimer', description: `${config.name} is for education only and is not financial advice.`,
  paragraphs: [
    ['p', `${config.name} is for education and information only. Nothing on this site or its channels is financial, investment, tax or trading advice, or a recommendation to buy, sell or hold anything.`],
    ['p', 'Verdicts such as "bullish" and "bearish" describe the usual textbook reading of a news story. They are generated automatically, can be wrong, and are not predictions. Gold often moves against them.'],
    ['p', 'Prices and exchange rates are indicative and may be delayed or wrong. Do not rely on them for trading or for buying and selling gold. Check with your dealer or broker.'],
    ['p', `${config.name} is not authorised or regulated by any financial regulator. Trading and investing involve risk, including losing your money. Make your own decisions, and consider speaking to a qualified adviser.`],
  ],
});

export const privacyPage = ({ state, config }) => simplePage({
  state, config, path: '/privacy', title: 'Privacy', description: `How ${config.name} handles your information.`,
  paragraphs: [
    ['p', `${config.name} has no accounts, no adverts, no analytics and no tracking cookies.`],
    ['p', 'Your chosen currency is saved in your own browser so the page remembers it. It is never sent to us.'],
    ['h2', 'Other services your browser contacts'],
    ['p', 'To show the page, your browser fetches the live gold price from gold-api.com and fonts from Google Fonts. Those services see your IP address, as any website you visit would. The site itself runs on Render, which keeps standard server logs.'],
    ['p', 'If you join our Telegram channel, Telegram\'s own privacy policy applies.'],
  ],
});

export const termsPage = ({ state, config }) => simplePage({
  state, config, path: '/terms', title: 'Terms', description: `The terms for using ${config.name}.`,
  paragraphs: [
    ['p', `By using ${config.name} you agree that it is provided as it is, for information only, with no promise that it is accurate, complete or always available.`],
    ['p', 'We are not responsible for any loss that comes from relying on this site. Read the disclaimer for more.'],
    ['p', 'Headlines belong to their publishers. Links to other websites do not mean we endorse them, and we do not control their content.'],
    ['p', 'We may change the site or these terms at any time.'],
  ],
});

export function statusPage({ state, config, report }) {
  const sources = Object.entries(report.sources).sort((a, b) => a[0].localeCompare(b[0]));
  const yes = (ok) => (ok ? 'Working' : 'Failing');
  const body = html`
  <section class="page-head"><div class="wrap"><h1>Site status</h1>
    <p class="lede">A health check for the site owner. It shows whether each data source answered on its last check.</p></div></section>
  <div class="wrap narrow">
    <div class="table-wrap"><table><tbody>
      <tr><th scope="row">Last check</th><td>${report.lastTickAt ? time(report.lastTickAt, config, 'dhm') : 'Not yet'}</td></tr>
      <tr><th scope="row">History storage</th><td>${report.storage === 'github' ? 'Saved to GitHub' : 'Temporary. It is lost on restart until GITHUB_DATA_TOKEN is added.'}${report.storageError ? html`<br><span class="num-down">${report.storageError}</span>` : ''}</td></tr>
      <tr><th scope="row">Telegram posts</th><td>${report.telegram}${report.telegramError ? html`<br><span class="num-down">${report.telegramError}</span>` : ''}</td></tr>
      <tr><th scope="row">Claude verdicts</th><td>${report.ai}${report.aiError ? html`<br><span class="num-down">${report.aiError}</span>` : ''}</td></tr>
      <tr><th scope="row">Posts today</th><td>${report.postsToday}</td></tr>
      <tr><th scope="row">Price checks today</th><td>${report.snapshotsToday}</td></tr>
      <tr><th scope="row">Daily closes saved</th><td>${report.closes}</td></tr>
    </tbody></table></div>
    <h2>Data sources</h2>
    ${sources.length ? html`<div class="table-wrap"><table>
      <thead><tr><th scope="col">Source</th><th scope="col">Result</th><th scope="col">Detail</th></tr></thead>
      <tbody>${sources.map(([name, s]) => html`<tr><th scope="row">${name}</th><td class="${s.ok ? 'num-up' : 'num-down'}">${yes(s.ok)}</td><td>${s.detail}</td></tr>`)}</tbody>
    </table></div>` : html`<p class="empty">The first check has not finished yet.</p>`}
  </div>`;
  return layout({ config, state, path: '/status', title: 'Site status', body, noindex: true });
}

export function notFoundPage({ state, config }) {
  const body = html`
  <section class="page-head"><div class="wrap"><h1>That page does not exist</h1>
    <p class="lede">The link may be old or mistyped.</p>
    <div class="buttons"><a class="btn btn-gold" href="/why-is-gold-moving-today">See why gold is moving today</a></div>
  </div></section>`;
  return layout({ config, state, path: '/404', title: 'Page not found', body, noindex: true });
}
