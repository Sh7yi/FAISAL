import { html, raw, esc } from '../lib/html.js';
import { changes } from '../core/state.js';

const NAV = [
  ['/why-is-gold-moving-today', 'Today'],
  ['/gold-news-calendar', 'News calendar'],
  ['/gold-calculator', 'Calculator'],
  ['/gold-rate', 'Gold price'],
  ['/markets', 'Markets'],
  ['/guides/', 'Gold School'],
];

const FOOT = [
  ['/gold-rate', 'Gold rate by country'],
  ['/gold-calculator', 'Gold calculator'],
  ['/gold-price-history', 'Price history'],
  ['/markets', 'Gold and other markets'],
  ['/gold-today', 'All earlier days'],
  ['/gold-news-calendar', 'News calendar'],
  ['/gold-market-hours', 'Market hours'],
  ['/gold-cheat-sheet', 'Cheat sheet'],
  ['/guides/', 'Gold School'],
  ['/about', 'About'],
  ['/disclaimer', 'Disclaimer'],
  ['/privacy', 'Privacy'],
  ['/terms', 'Terms'],
];

const logo = raw(`<svg class="logo" viewBox="0 0 40 28" aria-hidden="true"><path d="M8 2h24l7 24H1z" fill="#e4b43a"/><path d="M11 6h18l4 16H7z" fill="#f4d678"/><path d="M15 9h3l2.2 7.2L22.4 9h2.900l-4 11h-2.600z" fill="#2b1430"/></svg>`);

// Shared numbers for the page's script: live price, exchange rates, and past closes.
function siteData(state, config) {
  const c = changes(state);
  const base = (key) => c[key]?.base ?? null;
  return {
    price: state.price?.usd ?? null,
    fx: state.fx.rates,
    local: config.localCurrency,
    base: { day: base('day'), week: base('week'), month: base('month'), year: base('year') },
    updatedAt: state.lastTickAt,
    date: state.today?.date ?? null,
    live: state.today?.date ? ![0, 6].includes(new Date(`${state.today.date}T12:00:00Z`).getUTCDay()) : true,
  };
}

export function layout({ config, state, title, description, path = '/', body, noindex = false, active }) {
  const canonical = config.siteUrl ? `${config.siteUrl}${path}` : '';
  const version = config.assetVersion;
  const data = JSON.stringify(siteData(state, config)).replace(/</g, '\\u003c');
  const fullTitle = title.includes(config.name) ? title : `${title} | ${config.name}`;
  return html`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${fullTitle}</title>
<meta name="description" content="${description ?? config.tagline}">
${noindex ? raw('<meta name="robots" content="noindex">') : ''}
${canonical ? raw(`<link rel="canonical" href="${esc(canonical)}">`) : ''}
<meta name="theme-color" content="#2b1430">
<meta property="og:site_name" content="${config.name}">
<meta property="og:type" content="website">
<meta property="og:title" content="${fullTitle}">
<meta property="og:description" content="${description ?? config.tagline}">
${canonical ? raw(`<meta property="og:url" content="${esc(canonical)}"><meta property="og:image" content="${esc(config.siteUrl)}/og.png">`) : ''}
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icon-180.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible+Next:wght@400;600;700&family=Gloock&display=swap">
<link rel="stylesheet" href="/styles.css?v=${version}">
<script type="application/json" id="site-data">${raw(data)}</script>
<script src="/app.js?v=${version}" defer></script>
</head>
<body>
<a class="skip" href="#main">Skip to the content</a>
<header class="top">
  <div class="wrap top-inner">
    <a class="brand" href="/">${logo}<span>${config.name}</span></a>
    <nav aria-label="Main">
      ${NAV.map(([href, label]) => html`<a href="${href}" ${raw(active === href ? 'aria-current="page"' : '')}>${label}</a>`)}
      ${config.telegramUrl ? html`<a href="${config.telegramUrl}" rel="noopener">Telegram</a>` : ''}
    </nav>
  </div>
</header>
<main id="main">${body}</main>
<footer class="foot">
  <div class="wrap">
    <p class="foot-warning">Education only. Gold does not always react the same way. This is not financial advice.</p>
    <p>${config.name} explains what news usually means for gold. It is not financial, investment or trading advice, and it does not recommend buying or selling anything. ${config.name} is not authorised or regulated by any financial regulator. <a href="/disclaimer">Read the full disclaimer</a>.</p>
    <nav class="foot-links" aria-label="More pages">
      ${FOOT.map(([href, label]) => html`<a href="${href}">${label}</a>`)}
      ${config.telegramUrl ? html`<a href="${config.telegramUrl}" rel="noopener">Telegram</a>` : ''}
    </nav>
    <p class="foot-credit">Gold prices from <a href="https://gold-api.com" rel="noopener">gold-api.com</a>. <a href="https://www.exchangerate-api.com" rel="noopener">Rates by Exchange Rate API</a>. Headlines belong to their publishers and link back to them.
    ${config.contactEmail ? html` Contact: <a href="mailto:${config.contactEmail}">${config.contactEmail}</a>.` : ''}</p>
    <p class="foot-credit">© ${new Date().getUTCFullYear()} ${config.name}</p>
  </div>
</footer>
</body>
</html>`;
}
