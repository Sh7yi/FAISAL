// Reads RSS and Atom feeds. Written without a library so the project installs nothing.
const NAMED = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', rsquo: '’', lsquo: '‘', rdquo: '”',
  ldquo: '“', ndash: '–', mdash: '—', hellip: '…', eacute: 'é', copy: '©', reg: '®', trade: '™', euro: '€', pound: '£',
};

function decode(text) {
  return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, entity) => {
    if (entity[0] === '#') {
      const code = entity[1].toLowerCase() === 'x' ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : '';
    }
    return NAMED[entity.toLowerCase()] ?? whole;
  });
}

function clean(value) {
  if (!value) return '';
  const unwrapped = value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1');
  // Decode twice: some feeds double-encode, and tags can arrive encoded.
  const decoded = decode(decode(unwrapped));
  return decoded.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

function tag(block, names) {
  for (const name of names) {
    const match = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i'));
    if (match) return match[1];
  }
  return '';
}

function linkOf(block) {
  const text = clean(tag(block, ['link']));
  if (/^https?:\/\//i.test(text)) return text;
  const links = [...block.matchAll(/<link\b([^>]*?)\/?>/gi)].map((m) => m[1]);
  const pick = links.find((a) => /rel=["']alternate["']/i.test(a)) ?? links.find((a) => !/rel=/i.test(a)) ?? links[0];
  const href = pick?.match(/href=["']([^"']+)["']/i)?.[1];
  if (href) return decode(href);
  const guid = clean(tag(block, ['guid', 'id']));
  return /^https?:\/\//i.test(guid) ? guid : '';
}

function parseDate(value) {
  const text = clean(value);
  if (!text) return null;
  const date = new Date(text.replace(/\s+Z$/, ' GMT'));
  return Number.isNaN(date.getTime()) ? null : date;
}

export function parseFeed(xml, sourceName = '') {
  const blocks = [...String(xml).matchAll(/<(item|entry)\b[^>]*>([\s\S]*?)<\/\1>/gi)].map((m) => m[2]);
  const items = [];
  for (const block of blocks) {
    const title = clean(tag(block, ['title']));
    const link = linkOf(block);
    if (!title || !link) continue;
    items.push({
      title,
      link,
      date: parseDate(tag(block, ['pubDate', 'published', 'updated', 'dc:date'])),
      source: sourceName,
    });
  }
  return items;
}
