import { parseFeed } from './rss.js';
import { classify, isMacroHeadline, sameStory } from './classify.js';
import { aiClassify } from './ai.js';
import { normaliseCalendar, mergeCalendar, readingOf } from './calendar.js';
import { sendTelegram, telegramText } from './telegram.js';
import { lessonFor } from '../content/lessons.js';
import { changes, newDay, newState, PEGGED_FX, topStories } from '../core/state.js';
import { clock, isMarketDay, marketStatus, shortDate, tradingDate, tradingWindow, zoned, dowOf, dateInZone } from '../lib/time.js';
import { money, pct, sentence } from '../lib/format.js';

export const METALS = [
  { symbol: 'XAG', name: 'Silver' },
  { symbol: 'XPT', name: 'Platinum' },
  { symbol: 'XPD', name: 'Palladium' },
  { symbol: 'HG', name: 'Copper' },
  { symbol: 'BTC', name: 'Bitcoin' },
  { symbol: 'ETH', name: 'Ethereum' },
];

export const FRED_SERIES = [
  { id: 'DGS10', name: 'US 10-year Treasury yield', unit: '%' },
  { id: 'DTWEXBGS', name: 'US dollar index (broad)', unit: '' },
  { id: 'DCOILBRENTEU', name: 'Brent oil, dollars a barrel', unit: '$' },
];

const THEME_LABELS = {
  iran: 'Iran and Gulf oil', conflict: 'Conflict', fed: 'Fed rate talk', inflation: 'Inflation', jobs: 'US jobs',
  dollar: 'The dollar', yields: 'US bond yields', oil: 'Oil prices', demand: 'Gold demand', trade: 'Trade fights',
  fiscal: 'US government finances', politics: 'US politics', stocks: 'Stock markets', 'central-banks': 'Central banks', other: 'This story',
};

const clusterKey = (theme) => (theme === 'oil-gulf' ? 'iran' : theme);
const minutes = (n) => n * 60000;
const HOUR = 36e5;

function hash(text) {
  let h = 0;
  for (const c of text) h = (Math.imul(31, h) + c.charCodeAt(0)) | 0;
  return (h >>> 0).toString(36);
}

export class Collector {
  constructor({ config, store, now = () => new Date(), fetchImpl = fetch, log = () => {}, sleep }) {
    this.config = config;
    this.store = store;
    this.now = now;
    this.fetch = fetchImpl;
    this.log = log;
    this.sleep = sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    this.state = newState();
    this.state.today = newDay(tradingDate(now()));
    this.loaded = false;
    this.running = false;
    this.ticks = 0;
    this.dirty = false;
    this.lastPersist = 0;
    this.pending = {};
    this.dayCache = new Map();
    this.etags = new Map();
    this.storeError = null;
  }

  // Network helpers. A polite identity, a timeout, and no personal details.
  async #get(url, { headers = {}, timeout = 15000 } = {}) {
    const agent = `GoldNewsSite/1.0${this.config.siteUrl ? ` (+${this.config.siteUrl})` : ''}`;
    return this.fetch(url, { headers: { 'user-agent': agent, ...headers }, signal: AbortSignal.timeout(timeout), redirect: 'follow' });
  }

  async #json(url, options) {
    const response = await this.#get(url, options);
    if (!response.ok) throw new Error(`answered ${response.status}`);
    return response.json();
  }

  #mark(name, ok, detail) {
    this.state.sources[name] = { ok, at: this.now().toISOString(), detail: String(detail ?? '').slice(0, 160) };
  }

  async load() {
    try {
      const text = await this.store.read('state.json');
      if (text) {
        const saved = JSON.parse(text);
        this.state = { ...newState(), ...saved, closes: { XAU: {}, ...saved.closes } };
      }
      this.loaded = true;
      this.storeError = null;
    } catch (error) {
      // Never overwrite saved data we failed to read: stay unsaved and try again next time.
      this.loaded = false;
      this.storeError = error.message;
      this.log('store read failed', error.message);
    }
    if (!this.state.today) this.state.today = newDay(tradingDate(this.now()));
  }

  async tick() {
    if (this.running) return;
    this.running = true;
    try {
      if (!this.loaded) await this.load();
      const now = this.now();
      const quiet = !this.state.firstTickDone || (!this.store.durable && this.ticks === 0);
      this.rollover(now, quiet);
      await this.seedHistory(now);
      await this.updatePrices(now);
      await this.updateFx(now);
      await this.updateCalendar(now);
      await this.updateRates(now);
      const fresh = await this.fetchNews(now);
      const labelled = await this.label(fresh, now);
      this.publishNews(labelled, now, quiet);
      if (!quiet) this.publishDeveloping(now);
      this.publishMove(now, quiet);
      this.publishBrief(now, quiet);
      this.publishReminders(now, quiet);
      this.publishReopen(now, quiet);
      await this.deliverTelegram(now);
      this.prune(now);
      this.state.firstTickDone = true;
      this.state.lastTickAt = now.toISOString();
      this.ticks++;
      await this.persist(now);
      this.log(`tick done: ${fresh.length} new headlines, ${this.state.today.posts.length} posts today`);
    } catch (error) {
      this.log('tick failed', error);
    } finally {
      this.running = false;
    }
  }

  // Closes out yesterday's gold date once New York passes 5pm.
  rollover(now, quiet) {
    const date = tradingDate(now);
    const old = this.state.today;
    if (old.date === date) return;
    if (isMarketDay(old.date)) {
      const last = old.snapshots.at(-1)?.p;
      if (last) {
        const before = changes(this.state, last, 'XAU', old.date).day;
        this.state.closes.XAU[old.date] = last;
        for (const { symbol } of METALS) {
          const price = this.state.metals[symbol]?.price;
          if (price) (this.state.closes[symbol] ??= {})[old.date] = price;
        }
        old.posts.push(this.#closePost(old, last, before, now, quiet));
      }
    }
    if (old.posts.length || old.snapshots.length) {
      const headline = old.posts.find((p) => p.type === 'close')?.title ?? topStories(old, 1)[0]?.title ?? 'A quiet day for gold';
      this.state.days = [{ date: old.date, title: headline }, ...this.state.days.filter((d) => d.date !== old.date)];
      const doc = JSON.stringify(old);
      this.pending[`days/${old.date}.json`] = doc;
      this.dayCache.set(old.date, old);
    }
    this.state.today = newDay(date);
    this.dirty = true;
  }

  #closePost(day, price, change, now, quiet) {
    const end = tradingWindow(day.date).end;
    const at = end < now ? end : now;
    const friday = dowOf(day.date) === 5;
    const moved = change ? `, ${change.pct >= 0 ? 'up' : 'down'} ${Math.abs(change.pct).toFixed(1)}%` : '';
    const top = topStories(day, 1)[0];
    const post = {
      id: `c${day.date}`,
      type: 'close',
      at: at.toISOString(),
      title: `Gold closed ${friday ? 'for the week' : shortDate(day.date)} at ${money(price)}${moved}`,
      why: top ? `Biggest story of the day: ${sentence(top.title)}` : 'No single big story stood out today.',
      price,
    };
    if (!quiet && now - at < minutes(45)) this.#queue(post);
    return post;
  }

  // Optional: a free gold-api.com key fills in a year of past prices on the first run.
  async seedHistory(now) {
    const { state, config } = this;
    if (!config.goldApiKey || state.historySeeded) return;
    if (state.seedTriedAt && now - new Date(state.seedTriedAt) < HOUR) return;
    state.seedTriedAt = now.toISOString();
    try {
      const end = Math.floor(now.getTime() / 1000);
      const start = end - 370 * 86400;
      const rows = await this.#json(
        `${config.sources.goldApi}/history?symbol=XAU&startTimestamp=${start}&endTimestamp=${end}&groupBy=day&aggregation=avg&orderBy=asc`,
        { headers: { 'x-api-key': config.goldApiKey } },
      );
      const today = state.today.date;
      let added = 0;
      for (const row of rows) {
        const date = String(row.day ?? '').slice(0, 10);
        const value = Number(row.avg_price ?? row.price);
        if (date && value > 0 && date < today && isMarketDay(date) && !state.closes.XAU[date]) {
          state.closes.XAU[date] = value;
          added++;
        }
      }
      state.historySeeded = true;
      this.dirty = true;
      this.#mark('Past gold prices (gold-api.com)', true, `${added} days added`);
    } catch (error) {
      this.#mark('Past gold prices (gold-api.com)', false, error.message);
    }
  }

  async updatePrices(now) {
    const { state, config } = this;
    try {
      const gold = await this.#json(`${config.sources.goldApi}/price/XAU`);
      if (!(gold.price > 0)) throw new Error('no price in the answer');
      state.price = { usd: gold.price, at: now.toISOString(), quotedAt: gold.updatedAt ?? null };
      if (marketStatus(now).open) {
        state.today.snapshots.push({ t: now.toISOString(), p: Math.round(gold.price * 100) / 100 });
        if (state.today.snapshots.length > 400) state.today.snapshots.shift();
      }
      this.#mark('Gold price (gold-api.com)', true);
    } catch (error) {
      this.#mark('Gold price (gold-api.com)', false, error.message);
      return;
    }
    let failed = 0;
    for (const { symbol } of METALS) {
      await this.sleep(300); // Their terms ask for no more than a request or so a second.
      try {
        const quote = await this.#json(`${config.sources.goldApi}/price/${symbol}`);
        if (quote.price > 0) state.metals[symbol] = { price: quote.price, at: now.toISOString() };
      } catch {
        failed++;
      }
    }
    this.#mark('Other markets (gold-api.com)', failed < METALS.length, failed ? `${failed} of ${METALS.length} failed` : '');
  }

  async updateFx(now) {
    const { state, config } = this;
    if (state.fx.fetchedAt && now - new Date(state.fx.fetchedAt) < 6 * HOUR) return;
    try {
      const body = await this.#json(config.sources.fx);
      if (body.result !== 'success' || !body.rates) throw new Error('unexpected answer');
      state.fx = { fetchedAt: now.toISOString(), rates: { ...PEGGED_FX, ...body.rates } };
      this.#mark('Exchange rates', true);
    } catch (error) {
      state.fx.fetchedAt = now.toISOString();
      this.#mark('Exchange rates', false, error.message);
    }
  }

  async updateCalendar(now) {
    const { state, config } = this;
    if (state.calendar.fetchedAt && now - new Date(state.calendar.fetchedAt) < HOUR) return;
    state.calendar.fetchedAt = now.toISOString();
    try {
      const rows = await this.#json(config.sources.calendar);
      const fresh = normaliseCalendar(rows);
      state.calendar.events = mergeCalendar(state.calendar.events, fresh, now);
      this.dirty = true;
      this.#mark('Economic calendar', true, `${fresh.length} events kept`);
    } catch (error) {
      this.#mark('Economic calendar', false, error.message);
    }
  }

  async updateRates(now) {
    const { state, config } = this;
    if (state.rates.fetchedAt && now - new Date(state.rates.fetchedAt) < 6 * HOUR) return;
    state.rates.fetchedAt = now.toISOString();
    let failed = 0;
    for (const series of FRED_SERIES) {
      try {
        const response = await this.#get(`${config.sources.fred}?id=${series.id}`);
        if (!response.ok) throw new Error(`answered ${response.status}`);
        const rows = (await response.text()).trim().split(/\r?\n/).slice(1)
          .map((line) => line.split(','))
          .filter(([, value]) => value && value !== '.' && !Number.isNaN(Number(value)));
        const last = rows.at(-1);
        const prev = rows.at(-2);
        if (last) state.rates.series[series.id] = { value: Number(last[1]), prev: prev ? Number(prev[1]) : null, date: last[0] };
      } catch {
        failed++;
      }
    }
    this.#mark('Yields, dollar and oil (FRED)', failed < FRED_SERIES.length, failed ? `${failed} of ${FRED_SERIES.length} failed` : '');
  }

  // Collects headlines we have not seen before, dropping stale ones and repeats.
  async fetchNews(now) {
    const { state, config } = this;
    const results = await Promise.allSettled(config.sources.news.map(async (source) => {
      const headers = this.etags.has(source.url) ? { 'if-none-match': this.etags.get(source.url) } : {};
      const response = await this.#get(source.url, { headers, timeout: 12000 });
      if (response.status === 304) return { source, items: [] };
      if (!response.ok) throw new Error(`answered ${response.status}`);
      const etag = response.headers.get('etag');
      if (etag) this.etags.set(source.url, etag);
      const items = parseFeed(await response.text(), source.name);
      return { source, items, parsed: true };
    }));

    const fresh = [];
    const cutoff = now.getTime() - 30 * HOUR;
    results.forEach((outcome, i) => {
      const name = `News: ${config.sources.news[i].name}`;
      if (outcome.status === 'rejected') {
        this.#mark(name, false, outcome.reason?.message);
        return;
      }
      const { items, parsed } = outcome.value;
      if (parsed && !items.length) this.#mark(name, false, 'feed came back empty');
      else this.#mark(name, true, parsed ? `${items.length} headlines` : 'nothing new');
      for (const item of items) {
        const date = item.date ?? now;
        const key = hash(item.link);
        if (state.seen[key]) continue;
        state.seen[key] = now.getTime();
        if (date.getTime() < cutoff) continue;
        fresh.push({ ...item, date: date > now ? now : date });
      }
    });
    fresh.sort((a, b) => a.date - b.date);

    const unique = [];
    for (const item of fresh) {
      const repeat = unique.some((u) => sameStory(u.title, item.title)) || state.recent.some((r) => sameStory(r.title, item.title));
      if (!repeat) unique.push(item);
    }
    return unique;
  }

  async label(items, now) {
    const { state, config } = this;
    const labels = new Map(items.map((item) => [item, classify(item.title)]));
    const dateKey = dateInZone(now, 'UTC');
    if (state.ai.date !== dateKey) state.ai = { ...state.ai, date: dateKey, count: 0 };
    if (config.ai.key && state.ai.count < config.ai.dailyLimit) {
      const macro = items.filter((item) => isMacroHeadline(item.title)).slice(-25);
      if (macro.length) {
        try {
          const replies = await aiClassify(macro.map((m) => m.title), {
            key: config.ai.key, model: config.ai.model, version: config.ai.version, url: config.sources.anthropic, fetchImpl: this.fetch,
          });
          state.ai.count += macro.length;
          state.ai.ok = true;
          state.ai.error = null;
          macro.forEach((item, id) => {
            if (replies.has(id)) labels.set(item, replies.get(id) ? { ...replies.get(id), by: 'ai' } : null);
          });
        } catch (error) {
          state.ai.ok = false;
          state.ai.error = error.message;
          this.log('AI labelling failed, using built-in rules', error.message);
        }
      }
    }
    return items.map((item) => ({ item, label: labels.get(item) })).filter((row) => row.label);
  }

  #priceAt(at, now) {
    if (now - at < minutes(20)) return this.state.price?.usd ?? null;
    let best = null;
    let gap = minutes(20);
    for (const snap of this.state.today.snapshots) {
      const d = Math.abs(new Date(snap.t) - at);
      if (d < gap) { gap = d; best = snap.p; }
    }
    return best;
  }

  publishNews(labelled, now, quiet) {
    const { state } = this;
    for (const { item, label } of labelled) {
      const at = item.date;
      state.recent.push({
        t: at.toISOString(), title: item.title, link: item.link, source: item.source,
        theme: label.theme, verdict: label.verdict, importance: label.importance, why: label.why,
      });
      this.dirty = true;
      if (label.importance === 'low' || tradingDate(at) !== state.today.date) continue;
      const running = state.today.posts.find((p) => p.type === 'developing' && p.key === clusterKey(label.theme) && now - new Date(p.at) < 2 * HOUR);
      if (running && label.importance !== 'high') {
        running.items.push({ title: item.title, link: item.link, source: item.source, at: at.toISOString() });
        continue;
      }
      const post = {
        id: `n${hash(item.link)}`,
        type: 'news',
        at: at.toISOString(),
        verdict: label.verdict,
        importance: label.importance,
        theme: label.theme,
        title: item.title,
        why: label.why,
        price: this.#priceAt(at, now),
        source: item.source,
        link: item.link,
      };
      state.today.posts.push(post);
      if (!quiet && now - at < minutes(30)) this.#queue(post);
    }
  }

  // Several headlines on one subject in a short time become a single running story.
  publishDeveloping(now) {
    const { state } = this;
    const windowStart = now.getTime() - minutes(90);
    const groups = new Map();
    for (const row of state.recent) {
      if (row.importance === 'low' || new Date(row.t).getTime() < windowStart) continue;
      const key = clusterKey(row.theme);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(row);
    }
    for (const [key, rows] of groups) {
      if (rows.length < 3) continue;
      const recentPost = state.today.posts.some((p) => p.type === 'developing' && p.key === key && now - new Date(p.at) < 2 * HOUR);
      if (recentPost) continue;
      const count = { bullish: 0, bearish: 0, mixed: 0 };
      rows.forEach((r) => { count[r.verdict]++; });
      const verdict = count.bullish > count.bearish && count.bullish >= count.mixed ? 'bullish'
        : count.bearish > count.bullish && count.bearish >= count.mixed ? 'bearish' : 'mixed';
      const post = {
        id: `d${hash(key + now.toISOString())}`,
        type: 'developing',
        at: now.toISOString(),
        key,
        verdict,
        importance: rows.some((r) => r.importance === 'high') ? 'high' : 'medium',
        title: `${THEME_LABELS[key] ?? 'This story'}: ${rows.length} headlines in 90 minutes`,
        why: (rows.find((r) => r.verdict === verdict) ?? rows[0]).why,
        price: state.price?.usd ?? null,
        items: rows.slice(-5).reverse().map((r) => ({ title: r.title, link: r.link, source: r.source, at: r.t })),
      };
      state.today.posts.push(post);
      this.#queue(post);
      this.dirty = true;
    }
  }

  // A post each time the day's move passes another whole percent.
  publishMove(now, quiet) {
    const { state } = this;
    const today = state.today;
    const day = changes(state).day;
    if (!day || !marketStatus(now).open || !isMarketDay(today.date)) return;
    const dir = day.pct >= 0 ? 'up' : 'down';
    const level = Math.floor(Math.abs(day.pct));
    if (today.moveDir !== dir) { today.moveDir = dir; today.moveLevel = 0; }
    if (level < 1 || level <= today.moveLevel) return;
    today.moveLevel = level;
    if (quiet) return;
    const wanted = dir === 'up' ? 'bullish' : 'bearish';
    const since = now.getTime() - 6 * HOUR;
    const fits = state.recent
      .filter((r) => r.verdict === wanted && new Date(r.t).getTime() >= since)
      .sort((a, b) => b.t.localeCompare(a.t))
      .slice(0, 3);
    const post = {
      id: `m${hash(`${today.date}${dir}${level}`)}`,
      type: 'move',
      at: now.toISOString(),
      direction: dir,
      title: `Gold ${dir} ${Math.abs(day.pct).toFixed(1)}% today, now ${money(state.price.usd)}`,
      why: fits.length
        ? `${dir === 'up' ? 'Up' : 'Down'} ${money(Math.abs(day.abs))} since the last close. Recent stories that fit this move:`
        : `${dir === 'up' ? 'Up' : 'Down'} ${money(Math.abs(day.abs))} since the last close. No recent story fits this move, so it may be traders repositioning.`,
      price: state.price.usd,
      items: fits.map((r) => ({ title: r.title, link: r.link, source: r.source, at: r.t })),
    };
    today.posts.push(post);
    this.#queue(post);
    this.dirty = true;
  }

  publishBrief(now, quiet) {
    const { state, config } = this;
    const today = state.today;
    if (today.briefDone || !isMarketDay(today.date) || !state.price) return;
    const hour = zoned(now, config.timeZone).hour;
    const start = config.morningBriefHour;
    if (hour < start || hour >= start + 6) return;
    today.briefDone = true;
    this.dirty = true;

    const since = now.getTime() - 24 * HOUR;
    const rank = { high: 2, medium: 1, low: 0 };
    const stories = state.recent
      .filter((r) => r.importance !== 'low' && new Date(r.t).getTime() >= since)
      .sort((a, b) => rank[b.importance] - rank[a.importance] || b.t.localeCompare(a.t))
      .slice(0, 4);
    const count = { bullish: 0, bearish: 0 };
    stories.forEach((s) => { if (s.verdict in count) count[s.verdict]++; });
    const verdict = count.bullish > count.bearish ? 'bullish' : count.bearish > count.bullish ? 'bearish' : 'mixed';

    const end = now.getTime() + 24 * HOUR;
    const events = state.calendar.events.filter((e) => {
      const t = new Date(e.at).getTime();
      return t > now.getTime() && t <= end && e.heat >= 2;
    }).slice(0, 5);

    const day = changes(state).day;
    const sections = [];
    if (day) sections.push({ heading: 'Where gold is', rows: [`About ${money(state.price.usd)}, ${day.abs >= 0 ? 'up' : 'down'} ${money(Math.abs(day.abs))} (${pct(day.pct, 1)}) since the last close.`] });
    if (stories.length) sections.push({ heading: 'What happened', rows: stories.map((s) => `${s.verdict[0].toUpperCase()}${s.verdict.slice(1)}: ${s.title}`) });
    if (events.length) {
      sections.push({
        heading: 'Coming up',
        rows: events.map((e) => `${clock(new Date(e.at), config.timeZone)} ${config.timeZoneLabel}: ${e.name}${e.forecast ? ` (expected ${e.forecast}, last time ${e.previous || 'n/a'})` : ''}`),
        events: events.map((e) => ({ at: e.at, name: e.name, forecast: e.forecast, previous: e.previous })),
      });
    }
    sections.push({ heading: 'Lesson of the day', rows: [lessonFor(today.date)] });

    const post = {
      id: `b${today.date}`,
      type: 'brief',
      at: now.toISOString(),
      verdict,
      title: `Morning brief for ${shortDate(today.date)}: gold about ${money(state.price.usd)}`,
      sections,
      price: state.price.usd,
    };
    today.posts.push(post);
    if (!quiet) this.#queue(post);
  }

  publishReminders(now, quiet) {
    const { state } = this;
    for (const event of state.calendar.events) {
      if (event.heat < 2 || state.reminders[event.id]) continue;
      const lead = new Date(event.at) - now;
      if (lead <= 0 || lead > minutes(20)) continue;
      state.reminders[event.id] = now.getTime();
      this.dirty = true;
      const post = {
        id: `r${event.id}`,
        type: 'calendar',
        at: now.toISOString(),
        title: `Coming in ${Math.max(1, Math.round(lead / 60000))} minutes: ${event.name}`,
        items: [event.forecast && `Expected ${event.forecast}`, event.previous && `Last time ${event.previous}`, event.sub].filter(Boolean),
        why: readingOf(event),
        eventAt: event.at,
      };
      if (event.heat >= 3 || !quiet) state.today.posts.push(post);
      if (!quiet) this.#queue(post);
    }
  }

  publishReopen(now, quiet) {
    const { state } = this;
    const today = state.today;
    const status = marketStatus(now);
    if (today.reopenDone || status.open || status.reason !== 'weekend') return;
    const ny = zoned(now, 'America/New_York');
    if (ny.dow !== 0 || ny.hour < 12) return;
    today.reopenDone = true;
    this.dirty = true;
    const post = {
      id: `o${today.date}`,
      type: 'reopen',
      at: now.toISOString(),
      title: 'Gold reopens at 6pm New York today',
      opensAt: status.opensAt.toISOString(),
      price: state.price?.usd ?? null,
    };
    today.posts.push(post);
    if (!quiet) this.#queue(post);
  }

  #queue(post) {
    if (!this.config.telegram.token || !this.config.telegram.chatId) return;
    this.state.outbox.push({ id: post.id, at: this.now().toISOString(), text: telegramText(post, this.config) });
  }

  async deliverTelegram(now) {
    const { state, config } = this;
    const { token, chatId } = config.telegram;
    if (!token || !chatId) { state.outbox = []; return; }
    const dateKey = dateInZone(now, 'UTC');
    if (state.telegram.date !== dateKey) state.telegram = { ...state.telegram, date: dateKey, count: 0 };
    state.outbox = state.outbox.filter((m) => now - new Date(m.at) < minutes(45));
    while (state.outbox.length && state.telegram.count < config.telegramDailyLimit) {
      const message = state.outbox[0];
      try {
        await sendTelegram(message.text, { token, chatId, base: config.sources.telegram, fetchImpl: this.fetch });
        state.outbox.shift();
        state.telegram.count++;
        state.telegram.ok = true;
        state.telegram.error = null;
        this.dirty = true;
      } catch (error) {
        state.telegram.ok = false;
        // The Telegram token is part of the address, so never echo a raw error.
        state.telegram.error = String(error.message).replaceAll(token, '***').slice(0, 160);
        break;
      }
      await this.sleep(1100);
    }
  }

  prune(now) {
    const { state } = this;
    const seenCutoff = now.getTime() - 72 * HOUR;
    for (const [key, at] of Object.entries(state.seen)) if (at < seenCutoff) delete state.seen[key];
    const recentCutoff = now.getTime() - 48 * HOUR;
    state.recent = state.recent.filter((r) => new Date(r.t).getTime() >= recentCutoff);
    const reminderCutoff = now.getTime() - 14 * 24 * HOUR;
    for (const [key, at] of Object.entries(state.reminders)) if (at < reminderCutoff) delete state.reminders[key];
  }

  async persist(now, { force = false } = {}) {
    if (!this.loaded) return;
    const stale = now - this.lastPersist > minutes(15);
    if (!force && !this.dirty && !stale) return;
    const files = { ...this.pending, 'state.json': JSON.stringify(this.state) };
    try {
      await this.store.write(files);
      this.pending = {};
      this.dirty = false;
      this.lastPersist = now.getTime();
      this.storeError = null;
    } catch (error) {
      this.storeError = error.message;
      this.log('store write failed', error.message);
    }
  }

  // Fetches an earlier day's page from memory, or from saved data.
  async getDay(date) {
    if (date === this.state.today?.date) return this.state.today;
    if (this.dayCache.has(date)) return this.dayCache.get(date);
    const known = this.state.days.some((d) => d.date === date);
    if (!known) return null;
    const text = await this.store.read(`days/${date}.json`);
    if (!text) return null;
    const day = JSON.parse(text);
    if (this.dayCache.size > 40) this.dayCache.delete(this.dayCache.keys().next().value);
    this.dayCache.set(date, day);
    return day;
  }

  statusReport() {
    const { state, config, store } = this;
    return {
      lastTickAt: state.lastTickAt,
      storage: store.mode,
      storageError: this.storeError,
      telegram: config.telegram.token && config.telegram.chatId ? (state.telegram.ok === false ? 'failing' : 'on') : 'off',
      telegramError: state.telegram.error,
      ai: config.ai.key ? (state.ai.ok === false ? 'failing, using rules' : 'on') : 'off, using rules',
      aiError: state.ai.error,
      postsToday: state.today.posts.length,
      snapshotsToday: state.today.snapshots.length,
      closes: Object.keys(state.closes.XAU).length,
      sources: state.sources,
    };
  }
}
