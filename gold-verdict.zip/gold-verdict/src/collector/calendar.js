// Turns the raw economic calendar into the handful of releases that move gold,
// named in plain English, and builds the subscribable calendar file.
const KNOWN = [
  { match: /^Non-Farm Employment Change$/i, name: 'US jobs report (NFP)', heat: 3, higher: 'bearish', sub: 'New jobs last month' },
  { match: /^ADP Non-Farm/i, name: 'US private-company jobs estimate (ADP)', heat: 2, higher: 'bearish' },
  { match: /^Unemployment Rate$/i, name: 'US unemployment rate', heat: 3, higher: 'bullish' },
  { match: /^Average Hourly Earnings/i, name: 'US wage growth', heat: 2, higher: 'bearish' },
  { match: /^Unemployment Claims$/i, name: 'US weekly jobless claims', heat: 2, higher: 'bullish' },
  { match: /^JOLTS/i, name: 'US job openings (JOLTS)', heat: 2, higher: 'bearish' },
  { match: /^CPI m\/m$/i, name: 'US inflation (CPI), monthly', heat: 3, higher: 'bearish' },
  { match: /^CPI y\/y$/i, name: 'US inflation (CPI), yearly', heat: 3, higher: 'bearish' },
  { match: /^Core CPI m\/m$/i, name: 'US core inflation (CPI)', heat: 3, higher: 'bearish' },
  { match: /^Core PCE Price Index/i, name: 'US core PCE inflation, the Fed\'s favourite', heat: 3, higher: 'bearish' },
  { match: /^PPI m\/m$/i, name: 'US producer prices (PPI)', heat: 2, higher: 'bearish' },
  { match: /^Core PPI m\/m$/i, name: 'US core producer prices', heat: 2, higher: 'bearish' },
  { match: /^Federal Funds Rate$/i, name: 'Fed interest-rate decision', heat: 3, higher: 'bearish' },
  { match: /^FOMC Statement$/i, name: 'Fed statement', heat: 3 },
  { match: /^FOMC Press Conference$/i, name: 'Fed press conference', heat: 3 },
  { match: /^FOMC Meeting Minutes$/i, name: 'Fed meeting minutes', heat: 2 },
  { match: /^FOMC Economic Projections$/i, name: 'Fed forecasts', heat: 3 },
  { match: /^Fed Chair .* (Speaks|Testifies)$/i, name: 'Fed chair speaks', heat: 3 },
  { match: /^ISM Services PMI$/i, name: 'US services survey (ISM)', heat: 2, higher: 'bearish', sub: 'Above 50 means growing' },
  { match: /^ISM Manufacturing PMI$/i, name: 'US factory survey (ISM)', heat: 2, higher: 'bearish', sub: 'Above 50 means growing' },
  { match: /^Retail Sales m\/m$/i, name: 'US retail sales', heat: 2, higher: 'bearish' },
  { match: /^Core Retail Sales m\/m$/i, name: 'US core retail sales', heat: 2, higher: 'bearish' },
  { match: /GDP q\/q$/i, name: 'US economic growth (GDP)', heat: 2, higher: 'bearish' },
  { match: /UoM Consumer Sentiment$/i, name: 'US consumer sentiment', heat: 2, higher: 'bearish' },
  { match: /UoM Inflation Expectations$/i, name: 'US inflation expectations', heat: 2, higher: 'bearish' },
  { match: /^Congressional Elections$/i, name: 'US congressional elections', heat: 3, note: 'Elections do not move gold directly. They move the dollar and US interest rates, and gold follows those.' },
];

const FOREIGN_KEEP = [
  { country: 'EUR', match: /^Main Refinancing Rate$/i, name: 'European Central Bank rate decision', heat: 2 },
  { country: 'GBP', match: /^Official Bank Rate$/i, name: 'Bank of England rate decision', heat: 2 },
  { country: 'JPY', match: /^BOJ Policy Rate$/i, name: 'Bank of Japan rate decision', heat: 2 },
];

function hashId(text) {
  let h = 0;
  for (const c of text) h = (Math.imul(31, h) + c.charCodeAt(0)) | 0;
  return (h >>> 0).toString(36);
}

export function normaliseCalendar(rows) {
  const events = [];
  for (const row of rows) {
    const at = new Date(row.date);
    if (Number.isNaN(at.getTime())) continue;
    let known = null;
    if (row.country === 'USD') {
      known = KNOWN.find((k) => k.match.test(row.title));
      if (!known && row.impact !== 'High') continue;
    } else {
      known = FOREIGN_KEEP.find((k) => k.country === row.country && k.match.test(row.title));
      if (!known) continue;
    }
    events.push({
      id: hashId(`${row.country}${row.title}${at.toISOString()}`),
      at: at.toISOString(),
      country: row.country,
      name: known?.name ?? `US: ${row.title}`,
      sub: known?.sub ?? '',
      heat: known?.heat ?? 2,
      higher: known?.higher ?? null,
      note: known?.note ?? '',
      forecast: row.forecast || '',
      previous: row.previous || '',
    });
  }
  return events.sort((a, b) => a.at.localeCompare(b.at));
}

// Replaces this week's events with fresh ones and keeps the last fortnight for the record.
export function mergeCalendar(existing, fresh, now) {
  const earliestFresh = fresh[0]?.at ?? '9999';
  const cutoff = new Date(now.getTime() - 14 * 864e5).toISOString();
  const kept = existing.filter((e) => e.at < earliestFresh && e.at >= cutoff);
  return [...kept, ...fresh];
}

export function readingOf(event) {
  if (event.note) return event.note;
  if (event.country && event.country !== 'USD') return 'Rate moves abroad shift the dollar and global borrowing costs. Gold usually takes its cue from how the dollar reacts.';
  if (event.higher === 'bearish') return 'A higher number than expected usually hurts gold. A lower one usually helps.';
  if (event.higher === 'bullish') return 'A higher number than expected usually helps gold. A lower one usually hurts.';
  return 'Any hint of higher US rates usually hurts gold, and any hint of lower rates usually helps.';
}

const stamp = (iso) => iso.replace(/[-:]/g, '').replace(/\.\d+Z$/, 'Z');
const icsText = (text) => String(text).replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/([,;])/g, '\\$1');

function fold(line) {
  const out = [];
  let rest = line;
  while (Buffer.byteLength(rest) > 73) {
    let cut = 73;
    while (Buffer.byteLength(rest.slice(0, cut)) > 73) cut--;
    out.push(rest.slice(0, cut));
    rest = ` ${rest.slice(cut)}`;
  }
  out.push(rest);
  return out.join('\r\n');
}

export function buildIcs(events, { name, url, now = new Date() }) {
  const host = url ? new URL(url).host : 'gold-calendar';
  const lines = [
    'BEGIN:VCALENDAR', 'VERSION:2.0', `PRODID:-//${name}//Gold news calendar//EN`, 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH',
    `X-WR-CALNAME:${icsText(`${name}: gold news`)}`, 'REFRESH-INTERVAL;VALUE=DURATION:PT6H', 'X-PUBLISHED-TTL:PT6H',
  ];
  for (const e of events) {
    const start = new Date(e.at);
    const end = new Date(start.getTime() + 15 * 60000);
    const facts = [e.sub, e.forecast && `Expected ${e.forecast}`, e.previous && `Last time ${e.previous}`, readingOf(e)].filter(Boolean).join('\n');
    lines.push(
      'BEGIN:VEVENT', `UID:${e.id}@${host}`, `DTSTAMP:${stamp(now.toISOString())}`,
      `DTSTART:${stamp(start.toISOString())}`, `DTEND:${stamp(end.toISOString())}`,
      `SUMMARY:${icsText(e.name)}`, `DESCRIPTION:${icsText(facts)}`,
      'BEGIN:VALARM', 'ACTION:DISPLAY', 'TRIGGER:-PT15M', `DESCRIPTION:${icsText(`${e.name} in 15 minutes`)}`, 'END:VALARM',
      'END:VEVENT',
    );
  }
  lines.push('END:VCALENDAR');
  return `${lines.map(fold).join('\r\n')}\r\n`;
}
