import { esc } from '../lib/html.js';
import { clock } from '../lib/time.js';
import { money } from '../lib/format.js';

const MARK = { bullish: '🟢 Bullish for gold', bearish: '🔴 Bearish for gold', mixed: '⚪ Mixed for gold' };
const HEAT = { high: '🔥🔥🔥 High impact', medium: '🔥🔥 Medium impact' };
const bullet = (rows) => rows.map((r) => `• ${esc(r)}`).join('\n');

export function telegramText(post, config) {
  const lines = [];
  const priceLine = post.price ? `Gold ${money(post.price)}` : '';
  switch (post.type) {
    case 'news':
      lines.push(`⚡ ${MARK[post.verdict] ?? ''}${HEAT[post.importance] ? ` · ${HEAT[post.importance]}` : ''}`);
      lines.push(`<b>${esc(post.title)}</b>`, '', `Why: ${esc(post.why)}`);
      if (priceLine) lines.push(priceLine);
      break;
    case 'developing':
      lines.push(`📡 Developing · ${MARK[post.verdict] ?? ''}`, `<b>${esc(post.title)}</b>`, '', bullet(post.items.map((i) => i.title)), '', `What it means: ${esc(post.why)}`);
      if (priceLine) lines.push(priceLine);
      break;
    case 'move':
      lines.push(`${post.direction === 'up' ? '📈' : '📉'} <b>${esc(post.title)}</b>`, '', esc(post.why));
      if (post.items?.length) lines.push(bullet(post.items.map((i) => i.title)));
      break;
    case 'brief':
      lines.push(`☀️ <b>${esc(post.title)}</b>`, '');
      for (const section of post.sections) lines.push(`<b>${esc(section.heading)}</b>`, bullet(section.rows), '');
      break;
    case 'close':
      lines.push(`🌙 <b>${esc(post.title)}</b>`);
      if (post.why) lines.push('', esc(post.why));
      break;
    case 'reopen': {
      const opens = new Date(post.opensAt);
      lines.push(`🌙 <b>${esc(post.title)}</b>`, '', `${clock(opens, 'America/New_York')} New York, ${clock(opens, config.timeZone)} ${esc(config.timeZoneLabel)}.`);
      break;
    }
    case 'calendar':
      lines.push(`⏰ <b>${esc(post.title)}</b>`);
      if (post.items?.length) lines.push(bullet(post.items));
      lines.push('', esc(post.why));
      break;
    default:
      lines.push(esc(post.title));
  }
  if (config.siteUrl) lines.push('', `<a href="${esc(config.siteUrl)}">${esc(config.name)}</a> · Education only, not advice.`);
  return lines.join('\n').slice(0, 4000);
}

export async function sendTelegram(text, { token, chatId, base, fetchImpl = fetch }) {
  const response = await fetchImpl(`${base}/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true }),
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) {
    let reason = '';
    try { reason = (await response.json()).description ?? ''; } catch { /* no details */ }
    throw new Error(`Telegram answered ${response.status}${reason ? `: ${reason}` : ''}`);
  }
}
