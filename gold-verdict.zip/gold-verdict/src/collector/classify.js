// The free, built-in reader. It turns a headline into the textbook reading for gold:
// bullish, bearish or mixed, how big a deal it is, and one plain-English reason.
//
// The logic behind every rule: gold pays no interest and is priced in dollars. So
// higher US interest rates and a stronger dollar usually hurt it, and the opposite helps.

const WORD_UP = /\b(rise|rises|rose|rising|climb|climbs|climbed|climbing|jump|jumps|jumped|surge|surges|surged|surging|soar|soars|soared|spike|spikes|spiked|gain|gains|gained|rally|rallies|rallied|higher|highest|high|hot|hotter|accelerat\w*|increase|increases|increased|beat|beats|top|tops|topped|exceed\w*|strengthen\w*|firm|firms|firmer|stronger|strong|rebound\w*|hits? \S+ high)\b/i;
const WORD_DOWN = /\b(fall|falls|fell|falling|drop|drops|dropped|slide|slides|slid|sliding|sink|sinks|sank|slump|slumps|slumped|tumble|tumbles|tumbled|plunge|plunges|plunged|dip|dips|dipped|ease|eases|eased|easing|cool|cools|cooled|cooling|slow|slows|slowed|slowing|lower|lowest|low|weak|weaker|weakens?|weakened|soften\w*|decline|declines|declined|retreat\w*|miss|misses|missed|shrink\w*|below|slip|slips|slipped|slipping|sell)\b/i;
const CLAUSE = /\s(?:as|after|on|while|but|despite|amid|ahead|before|when|because|with|and)\s|[,;:–—|]/i;

const US = /\b(US|U\.S\.?|USA|America|American|Fed|Federal Reserve|FOMC|Powell|Warsh|Treasury|Treasuries|White House|Trump|Wall Street|Washington|Congress)\b/;
const FOREIGN = /\b(UK|Britain|British|BoE|euro ?zone|ECB|German\w*|France|French|Ital\w+|Spain|Spanish|Japan\w*|BoJ|China|Chinese|PBOC|India\w*|Australia\w*|RBA|New Zealand|RBNZ|Canad\w+|BoC|Swiss|SNB|Korea\w*|Brazil\w*|Mexic\w+|Turk\w+|Russia\w*|Norway|Norges|Sweden|Riksbank)\b/i;

function surprise(title) {
  if (/\b(less|slower|softer|cooler|lower|weaker|smaller|below)\b[^,.;]{0,20}\b(than )?(expected|forecasts?|estimates?|expectations|consensus)\b/i.test(title)) return 'down';
  if (/\b(more|faster|hotter|higher|stronger|bigger|above)\b[^,.;]{0,20}\b(than )?(expected|forecasts?|estimates?|expectations|consensus)\b/i.test(title)) return 'up';
  const versus = title.match(/(-?[\d.,]+)\s*([%kKmMbB]?)\s*(?:vs\.?|versus|against)\s*(?:about\s+)?(-?[\d.,]+)\s*[%kKmMbB]?\s*(?:expected|forecast|est\b|estimate|exp\b|consensus)/i);
  if (versus) {
    const a = parseFloat(versus[1].replace(/,/g, ''));
    const b = parseFloat(versus[3].replace(/,/g, ''));
    if (a > b) return 'up';
    if (a < b) return 'down';
  }
  return null;
}

// Finds which way the thing named in `subject` moved, reading only its own clause so
// that "Dollar steady as gold rises" is not mistaken for a rising dollar.
function moved(title, subject) {
  const match = title.match(subject);
  if (!match) return null;
  const start = match.index;
  const end = start + match[0].length;
  const after = title.slice(end).split(CLAUSE)[0];
  const beforeParts = title.slice(0, start).split(CLAUSE);
  const before = beforeParts[beforeParts.length - 1];
  const firstHit = (text) => {
    const up = text.match(WORD_UP);
    const down = text.match(WORD_DOWN);
    if (up && down) return up.index <= down.index ? 'up' : 'down';
    return up ? 'up' : down ? 'down' : null;
  };
  return firstHit(after) ?? firstHit(before);
}

const result = (theme, verdict, importance, why) => ({ theme, verdict, importance, why });

const WHY = {
  hotterUS: 'Hotter US prices make higher interest rates more likely. Gold pays no interest, so it loses appeal.',
  coolerUS: 'Cooler US prices take pressure off the Fed to keep rates high. Lower rates usually help gold.',
  hotterAbroad: 'Hotter prices abroad push central banks towards higher rates worldwide. That usually weighs on gold, which pays no interest.',
  coolerAbroad: 'Cooler prices abroad ease the pressure for higher rates worldwide, which usually helps gold.',
  hawkish: 'Higher US interest rates make savings and bonds pay more, and gold pays nothing, so it tends to lose out.',
  dovish: 'Lower US interest rates make gold less costly to hold and tend to weaken the dollar. Both usually help it.',
  strongJobs: 'A strong US jobs market gives the Fed room to keep rates high, which usually hurts gold.',
  weakJobs: 'A weak US jobs market makes lower interest rates more likely, which usually helps gold.',
  strongDollar: 'Gold is priced in dollars. A stronger dollar makes it more expensive for everyone else and tends to push it down.',
  weakDollar: 'Gold is priced in dollars. A weaker dollar makes it cheaper for everyone else and tends to lift it.',
  highYields: 'Higher yields mean bonds pay more. Gold pays nothing, so it looks less attractive next to them.',
  lowYields: 'Lower yields mean bonds pay less, so holding gold, which pays nothing, costs less. That usually helps it.',
  oilShock: 'Trouble for tankers threatens oil flows from the Gulf. More expensive oil keeps inflation and US interest rates high, which gold does not like.',
  oilUp: 'More expensive oil feeds inflation, which can keep US interest rates high. That usually weighs on gold.',
  oilDown: 'Cheaper oil cools inflation, which makes lower US interest rates more likely. That usually helps gold.',
  gulfWar: 'Fear can send investors to gold for protection. But if the conflict pushes oil higher, inflation and US rates stay high, which hurts gold.',
  gulfPeace: 'Calmer times cut demand for gold as protection, but cheaper oil can bring lower US rates. The two pull in opposite directions.',
  war: 'Conflict makes investors nervous, and nervous investors often buy gold for protection.',
  peace: 'Less danger means less need for gold as protection, so some of that safety buying can unwind.',
};

const GULF = /\b(Iran\w*|Tehran|Hormuz|IRGC|Khamenei|Gulf|Israel|Netanyahu)\b/i;
const CONFLICT_PLACES = /\b(Iran\w*|Tehran|Hormuz|IRGC|Khamenei|Russia\w*|Putin|Ukrain\w*|NATO|Taiwan|North Korea|Pyongyang)\b/i;
const CONFLICT_ACTION = /\b(attack\w*|strik\w*|struck|missiles?|war|escalat\w*|retaliat\w*|invad\w*|invasion|bomb\w*|drones?|threat\w*|warn\w*|mobili[sz]\w*|shoot\w*|shot|nuclear|hits)\b/i;
const PEACE = /\b(ceasefire|truce|peace (deal|talks|plan)|de-?escalat\w*|deal|talks)\b/i;

function fedRule(title) {
  const isFed = /\b(Fed|Fed's|Federal Reserve|FOMC|Powell|Warsh|Federal Open Market Committee)\b/.test(title);
  const foreign = FOREIGN.test(title) && !isFed;
  const hasRateBet = /\b(rate[- ]?(hike|cut|rise)s?|hikes?|interest rates?|raises? rates|cuts? rates|hike bets|cut bets)\b/i.test(title);
  if (foreign || (!isFed && !hasRateBet)) return null;

  const dovish = /\b(hike bets?|hike hopes|hike expectations)\b[^,;]{0,20}\b(fade|fades|fading|ease|eases|easing|recede|recedes|cool|cools|dim|dims|shrink|shrinks|wane|wanes)\b|\b(fading|easing|cooling) (\w+ )?hike bets?\b|\b(cut bets?|bets on (\w+ ){0,3}cuts?)\b[^,;]{0,20}\b(rise|rises|rising|grow|grows|growing|build|builds|jump|jumps)\b|\b(rising|growing) (\w+ )?cut bets?\b|\bcuts? (interest )?rates\b|\b(signals?|sees?|backs?|hints? at|delivers?|announces?) (\w+ ){0,2}(rate )?cuts?\b|\brate cuts? (coming|likely|ahead)\b|\bdovish\b|\bno (rate )?hike\b/i;
  const hawkish = /\b(hike bets?|hike hopes|hike expectations)\b[^,;]{0,20}\b(rise|rises|rising|grow|grows|growing|build|builds|climb|climbs|jump|jumps)\b|\b(rising|growing|higher) (\w+ )?hike bets?\b|\braises? (interest )?rates\b|\braised (interest )?rates\b|\b(signals?|sees?|backs?|hints? at|delivers?|announces?) (\w+ ){0,2}(rate )?(hikes?|rises?)\b|\brate hikes? (coming|likely|ahead)\b|\bhawkish\b|\b(cut bets?)\b[^,;]{0,20}\b(fade|fades|fading|ease|eases|dim|dims)\b|\bno (rate )?cuts?\b|\bdelays? (rate )?cuts?\b/i;

  if (dovish.test(title)) return result('fed', 'bullish', isFed && /\bcuts?\b.*\brates\b/i.test(title) ? 'high' : 'medium', WHY.dovish);
  if (hawkish.test(title)) return result('fed', 'bearish', isFed && /\braise[sd]? (interest )?rates\b/i.test(title) ? 'high' : 'medium', WHY.hawkish);

  if (isFed && /\b(FOMC statement|rate decision|policy decision|holds? (interest )?rates|keeps? (interest )?rates|leaves? (interest )?rates|minutes of the federal open market committee|fomc minutes|fed minutes)\b/i.test(title)) {
    return result('fed', 'mixed', 'high', 'The move depends on the wording. Any hint of higher rates is bad for gold, and any hint of lower rates is good.');
  }
  return null;
}

function inflationRule(title) {
  const subject = /\b(inflation|CPI|core PCE|PCE|consumer prices|producer prices|PPI)\b/i;
  if (!subject.test(title)) return null;
  if (/\b(expectations?|gauge|target|fight|hedge)\b/i.test(title) && !surprise(title)) return null;
  const dir = surprise(title) ?? moved(title, subject);
  if (!dir) return null;
  const foreign = FOREIGN.test(title) && !US.test(title);
  if (foreign) {
    if (!/\b(euro ?zone|UK|Britain|British|German\w*)\b/i.test(title)) return null;
    return dir === 'up' ? result('inflation', 'bearish', 'medium', WHY.hotterAbroad) : result('inflation', 'bullish', 'medium', WHY.coolerAbroad);
  }
  return dir === 'up' ? result('inflation', 'bearish', 'high', WHY.hotterUS) : result('inflation', 'bullish', 'high', WHY.coolerUS);
}

function jobsRule(title) {
  const big = /\b(non-?farm|payrolls?|NFP|jobs report)\b/i;
  const reverse = /\b(jobless claims|unemployment claims|initial claims|US unemployment|U\.S\. unemployment|US jobless rate|U\.S\. jobless rate)\b/i;
  const other = /\b(ADP|job openings|JOLTS|US jobs|U\.S\. jobs|private[- ](sector )?(jobs|payrolls)|US hiring|U\.S\. hiring|US job growth|U\.S\. job growth|US employers|U\.S\. employers)\b/i;
  const subject = [big, reverse, other].find((r) => r.test(title));
  if (!subject || (FOREIGN.test(title) && !US.test(title))) return null;
  let dir = surprise(title) ?? moved(title, subject);
  if (!dir) return null;
  if (subject === reverse) dir = dir === 'up' ? 'down' : 'up';
  const importance = subject === big ? 'high' : 'medium';
  return dir === 'up' ? result('jobs', 'bearish', importance, WHY.strongJobs) : result('jobs', 'bullish', importance, WHY.weakJobs);
}

function goldDemandRule(title) {
  if (!/\bgold\b/i.test(title)) return null;
  if (/\bcentral banks?\b|\bPBOC\b|\bgold reserves\b/i.test(title)) {
    if (/\b(buy\w*|bought|purchas\w*|add\w*|accumulat\w*|boost\w*|increas\w*|record)\b/i.test(title)) {
      return result('demand', 'bullish', 'medium', 'Central banks are among the biggest gold buyers. Steady buying supports the price, whatever the news of the day.');
    }
    if (/\b(sell\w*|sold|cut\w*|reduc\w*|slow\w*)\b/i.test(title)) {
      return result('demand', 'bearish', 'medium', 'Less buying from central banks removes one of the steadiest sources of demand for gold.');
    }
  }
  if (/\bgold\b.*\bETFs?\b|\bETFs?\b.*\bgold\b/i.test(title)) {
    if (/\b(inflows?|buy\w*|add\w*|holdings? (rise|rose|climb))\b/i.test(title)) return result('demand', 'bullish', 'medium', 'Money flowing into gold funds means investors are buying, which supports the price.');
    if (/\b(outflows?|sell\w*|redeem\w*|holdings? (fall|fell|drop))\b/i.test(title)) return result('demand', 'bearish', 'medium', 'Money leaving gold funds means investors are selling, which weighs on the price.');
  }
  if (/\bgold demand\b|\bdemand for gold\b|\bjewellery demand\b|\bjewelry demand\b/i.test(title)) {
    const dir = moved(title, /\b(gold demand|demand for gold|jewell?ery demand)\b/i);
    if (dir === 'down') return result('demand', 'bearish', 'medium', 'Fewer buyers of physical gold removes some support, though investors matter more for the daily price.');
    if (dir === 'up') return result('demand', 'bullish', 'medium', 'More buyers of physical gold adds support, though investors matter more for the daily price.');
  }
  return null;
}

function dollarRule(title) {
  if (/\b(australian|aussie|canadian|kiwi|new zealand|singapore|hong kong|taiwan) dollar\b/i.test(title)) return null;
  if (/\bsell (the )?(usd|dollar)\b/i.test(title)) return result('dollar', 'bullish', 'low', WHY.weakDollar);
  const subject = /\b(dollar index|US dollar|U\.S\. dollar|DXY|dollar|greenback|USD(?![/\w]))\b/i;
  if (!subject.test(title)) return null;
  const dir = moved(title, subject);
  if (!dir) return null;
  const big = /\b(\S+-(week|month|year)|multi-\w+|year|month|week|record|sharply|plunge\w*|surge\w*|soar\w*|tumble\w*)\b/i.test(title);
  return dir === 'up'
    ? result('dollar', 'bearish', big ? 'medium' : 'low', WHY.strongDollar)
    : result('dollar', 'bullish', big ? 'medium' : 'low', WHY.weakDollar);
}

function yieldsRule(title) {
  if (FOREIGN.test(title) && !US.test(title)) return null;
  const subject = /\b(Treasury yields?|bond yields?|10-year yields?|10-year Treasury|10-yr|borrowing costs|yields?)\b/i;
  if (!subject.test(title)) return null;
  const dir = moved(title, subject);
  if (!dir) return null;
  const big = /\b(10-year|10-yr|\S+-(week|month|year)|record)\b/i.test(title);
  return dir === 'up'
    ? result('yields', 'bearish', big ? 'medium' : 'low', WHY.highYields)
    : result('yields', 'bullish', big ? 'medium' : 'low', WHY.lowYields);
}

function oilRule(title) {
  const lane = /\b(Hormuz|tankers?|Red Sea|oil (flows?|shipping|shipments?))\b/i;
  if (lane.test(title)) {
    if (/\b(reopen\w*|resum\w*|safe passage)\b/i.test(title)) return result('oil-gulf', 'bullish', 'medium', WHY.oilDown);
    if (/\b(destroy\w*|mines?|attack\w*|seiz\w*|shut\w*|clos\w*|block\w*|struck|strik\w*|detain\w*|threat\w*|hit)\b/i.test(title)) {
      const big = /\b(destroy\w*|attack\w*|seiz\w*|shut\w*|clos\w*|block\w*)\b/i.test(title);
      return result('oil-gulf', 'bearish', big ? 'high' : 'medium', WHY.oilShock);
    }
  }
  if (/\b(inventor\w*|stockpiles?|rig count|refiner\w*|earnings|profit|demand forecast|output forecast)\b/i.test(title)) return null;
  const subject = /\b(oil prices?|oil|brent|crude|WTI)\b/i;
  if (!subject.test(title)) return null;
  const dir = moved(title, subject);
  if (!dir) return null;
  const big = /\$\d{2,3}\b|\b(surg\w*|soar\w*|spik\w*|plung\w*|tumbl\w*|record|\S+-(week|month|year))\b/i.test(title);
  return dir === 'up'
    ? result('oil', 'bearish', big ? 'medium' : 'low', WHY.oilUp)
    : result('oil', 'bullish', big ? 'medium' : 'low', WHY.oilDown);
}

function conflictRule(title) {
  if (!CONFLICT_PLACES.test(title)) return null;
  const gulf = GULF.test(title);
  const theme = gulf ? 'iran' : 'conflict';
  if (PEACE.test(title) && !/\b(far off|collapse\w*|fail\w*|stall\w*|reject\w*)\b/i.test(title)) {
    return gulf
      ? result(theme, 'mixed', 'medium', WHY.gulfPeace)
      : result(theme, 'bearish', 'medium', WHY.peace);
  }
  if (!CONFLICT_ACTION.test(title)) return null;
  return gulf ? result(theme, 'mixed', 'medium', WHY.gulfWar) : result(theme, 'bullish', 'medium', WHY.war);
}

function otherRules(title) {
  if (/\b(tariffs?|trade war|export controls?)\b/i.test(title) && /\b(US|U\.S\.|Trump|China|EU|White House)\b/.test(title)) {
    if (/\b(deal|truce|pause\w*|delay\w*|lift\w*|remov\w*|cut\w*)\b/i.test(title)) {
      return result('trade', 'bearish', 'medium', 'Easing trade fights makes investors less nervous, so there is less call for gold as protection.');
    }
    return result('trade', 'bullish', 'medium', 'Trade fights make the economy harder to read, and that uncertainty tends to send some money to gold.');
  }
  if (/\b(government shutdown|debt ceiling|debt limit|US credit rating|U\.S\. credit rating|downgrades? (the )?(US|U\.S\.))\b/i.test(title)) {
    return result('fiscal', 'bullish', 'medium', 'Doubts over US government finances weaken trust in the dollar, and gold is the usual alternative.');
  }
  const usVote = /\b(midterms?|election)\b/i.test(title) && /\b(Democrat\w*|Republican\w*|Senate|House|Congress|Trump|US|U\.S\.)\b/.test(title);
  const partyWin = /\b(Democrats?|Republicans?)\b/.test(title) && /\b(Senate|House|Congress)\b/.test(title) && /\b(win|wins|won|control|take|takes|took|flip|flips|flipped)\b/i.test(title);
  const marketStory = /\b(Nikkei|futures|stocks?|shares|chip)\b/i.test(title);
  if ((usVote || partyWin) && !marketStory && !(FOREIGN.test(title) && !US.test(title))) {
    return result('politics', 'mixed', 'medium', 'Elections do not move gold directly. They move the dollar and US interest rates, and gold follows those.');
  }
  if (/\b(Wall Street|S&P 500|Nasdaq|Dow|global stocks|US stocks|U\.S\. stocks)\b/.test(title) && /\b(plung\w*|tumbl\w*|crash\w*|sell-?off|rout)\b/i.test(title)) {
    return result('stocks', 'mixed', 'medium', 'A stock rout can send money to gold for safety. But big falls can also force traders to sell gold to raise cash.');
  }
  if (/^monetary policy decisions?$/i.test(title)) {
    return result('central-banks', 'mixed', 'medium', 'Rate moves abroad shift the dollar and global borrowing costs. Gold usually takes its cue from how the dollar reacts.');
  }
  if (/\b(ECB|European Central Bank|Bank of England|BoE|Bank of Japan|BoJ)\b/.test(title)
    && /\b(rate decision|monetary policy decisions?|raises? (interest )?rates|cuts? (interest )?rates|holds? (interest )?rates|keeps? (interest )?rates|rate (hike|cut)s?)\b/i.test(title)) {
    return result('central-banks', 'mixed', 'medium', 'Rate moves abroad shift the dollar and global borrowing costs. Gold usually takes its cue from how the dollar reacts.');
  }
  return null;
}

const RULES = [fedRule, inflationRule, jobsRule, goldDemandRule, oilRule, conflictRule, dollarRule, yieldsRule, otherRules];

export function classify(title) {
  for (const rule of RULES) {
    const hit = rule(title);
    if (hit) return hit;
  }
  return null;
}

// A wider net, used only to decide which headlines are worth sending to the AI reader.
const MACRO = /\b(gold|bullion|fed|fomc|federal reserve|inflation|cpi|pce|ppi|jobs?|payrolls?|unemployment|jobless|dollar|usd|yields?|treasur\w+|oil|brent|crude|hormuz|tankers?|iran\w*|israel|russia\w*|ukrain\w*|taiwan|nato|north korea|war|missiles?|tariffs?|central banks?|ecb|bank of england|boj|rates?|recession|gdp|deficit|shutdown|elections?|midterms?|stocks?|wall street|sanctions?)\b/i;
export const isMacroHeadline = (title) => MACRO.test(title);

const STOP = new Set('a an and are as at be but by for from has have in is it its of on or says say said that the their to was were will with after over amid new us u.s'.split(' '));

export function titleTokens(title) {
  return new Set(title.toLowerCase().replace(/[^a-z0-9$% ]+/g, ' ').split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w)));
}

// True when two headlines are the same story reworded by different publishers.
export function sameStory(a, b) {
  const x = titleTokens(a);
  const y = titleTokens(b);
  if (!x.size || !y.size) return false;
  let shared = 0;
  for (const w of x) if (y.has(w)) shared++;
  return shared / (x.size + y.size - shared) >= 0.5;
}
