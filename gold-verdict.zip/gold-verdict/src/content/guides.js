// Gold School: short lessons in plain English. Written for this site.
export const GUIDES = [
  {
    slug: 'nfp',
    title: 'How the US jobs report moves gold',
    summary: 'Why the first Friday of the month is often the biggest day for gold.',
    body: [
      ['p', 'Once a month the US government reports how many jobs the country added. Traders call it NFP, short for non-farm payrolls. It comes out at 8:30am New York time, usually on the first Friday of the month, and gold can move sharply within seconds.'],
      ['h2', 'Why jobs matter to a metal'],
      ['p', 'The link is interest rates. The Federal Reserve sets US rates partly by looking at how strong the jobs market is. Plenty of jobs means the economy can cope with higher rates. Few jobs means the Fed may need to lower them.'],
      ['p', 'Gold pays no interest. When rates rise, money in savings and bonds earns more, and gold looks less attractive. When rates fall, the opposite happens.'],
      ['h2', 'The textbook reading'],
      ['ul', ['More jobs than expected: usually bad for gold.', 'Fewer jobs than expected: usually good for gold.', 'Faster wage growth: usually bad for gold, because it can feed inflation.']],
      ['h2', 'What catches people out'],
      ['p', 'The number on its own means little. What counts is the gap between the result and the forecast. A strong number that everyone expected can leave gold unmoved. Last month\'s figure also gets revised, and a big revision can outweigh the headline.'],
    ],
  },
  {
    slug: 'cpi',
    title: 'Does inflation help or hurt gold?',
    summary: 'Gold is called an inflation hedge, yet hot inflation numbers often push it down.',
    body: [
      ['p', 'Many people are surprised to see gold fall on a day when US inflation comes in high. Gold is meant to protect you from rising prices, so why does this happen?'],
      ['h2', 'Short term against long term'],
      ['p', 'Over many years, gold has tended to hold its buying power as money loses value. That is the long-term story. Over a single day, traders care about something else: what the Fed will do next.'],
      ['p', 'A hot inflation number makes higher interest rates more likely. Higher rates make gold less attractive, because it pays nothing. So the same number can be good for gold over ten years and bad for it over ten minutes.'],
      ['h2', 'The textbook reading'],
      ['ul', ['Inflation above forecast: usually bad for gold on the day.', 'Inflation below forecast: usually good for gold on the day.']],
      ['h2', 'CPI, PCE and "core"'],
      ['p', 'CPI measures prices paid by households. PCE is a similar measure and the one the Fed prefers. "Core" removes food and energy, which jump around, so it gives a steadier picture. Traders often react more to core than to the main figure.'],
    ],
  },
  {
    slug: 'fed',
    title: 'How the Fed affects gold',
    summary: 'Interest rates are the single biggest force on gold. The Fed sets them.',
    body: [
      ['p', 'The Federal Reserve is the US central bank. Eight times a year it decides on interest rates, and those decisions spread across the world. Few things move gold more.'],
      ['h2', 'Two reasons rates matter'],
      ['ul', ['Gold pays no interest. Higher rates make bonds and savings pay more, so holding gold costs you more in lost income.', 'Higher US rates tend to strengthen the dollar. Gold is priced in dollars, so a stronger dollar makes it more expensive for everyone else.']],
      ['h2', 'Words often beat decisions'],
      ['p', 'The decision itself is usually well known in advance. The surprise tends to be in the statement, the forecasts and the chair\'s press conference. Traders listen for hints about the next meeting. "Hawkish" means leaning towards higher rates, which usually hurts gold. "Dovish" means leaning towards lower rates, which usually helps it.'],
    ],
  },
  {
    slug: 'war-oil-and-gold',
    title: 'War, oil and gold',
    summary: 'Why a war can push gold down, even though it is meant to be a safe haven.',
    body: [
      ['p', 'The old rule says war is good for gold. Frightened investors buy it for protection. That still happens, but it is only half the story.'],
      ['h2', 'The oil route'],
      ['p', 'If a conflict threatens oil supplies, such as trouble in the Gulf or the Strait of Hormuz, oil prices rise. More expensive oil feeds inflation. Higher inflation keeps interest rates high. High rates hurt gold.'],
      ['h2', 'Two forces, one headline'],
      ['ul', ['Fear pulls gold up.', 'More expensive oil and higher rates pull gold down.']],
      ['p', 'Which one wins depends on the moment. When inflation is already the main worry, the oil route can dominate, and gold can fall on frightening news. When inflation is calm, fear tends to win.'],
      ['p', 'A peace deal can work the same way in reverse: less fear, but cheaper oil and possibly lower rates.'],
    ],
  },
  {
    slug: 'dollar',
    title: 'The dollar and gold',
    summary: 'Why the two so often move in opposite directions.',
    body: [
      ['p', 'Gold is priced in US dollars around the world. If the dollar rises, a buyer paying in euros, rupees or dirhams needs more of their own money for the same ounce, unless their currency is tied to the dollar. Fewer buyers usually means a lower price.'],
      ['p', 'A weaker dollar works the other way. Gold gets cheaper for most of the world and demand tends to pick up.'],
      ['h2', 'A note for the Gulf'],
      ['p', 'The UAE dirham, Saudi riyal, Qatari riyal, Omani rial and Bahraini dinar are pegged to the dollar. So for buyers in those countries, the local price of gold moves almost exactly with the dollar price.'],
      ['h2', 'It is not a law'],
      ['p', 'Gold and the dollar can rise together, especially when the whole world is scared and buying both for safety. Treat the link as a strong habit, not a rule.'],
    ],
  },
  {
    slug: 'yields',
    title: 'Bond yields: gold\'s real rival',
    summary: 'What a yield is, and why traders watch it next to the gold price.',
    body: [
      ['p', 'A bond yield is the return you get for lending to a government. The US 10-year Treasury yield is the one the world watches. When it rises, safe money earns more. Since gold earns nothing, it has to compete with that return.'],
      ['h2', 'Real yields'],
      ['p', 'What matters most is the yield after inflation, known as the real yield. If bonds pay 5% and inflation is 3%, the real yield is 2%. A higher real yield is a stronger rival to gold. A real yield near zero or below makes gold much easier to hold.'],
      ['p', 'This is why you often see gold rise on days when yields fall, even with no gold news at all.'],
    ],
  },
  {
    slug: 'central-banks',
    title: 'Why central banks buy gold',
    summary: 'The quiet buyers behind the price.',
    body: [
      ['p', 'Central banks hold gold in their reserves alongside dollars and other currencies. Many have been adding to it, partly to rely less on any one currency.'],
      ['p', 'They buy in large amounts and rarely react to the news of the day. That gives gold a slow, steady support that does not show up in any single headline, and it can help explain why gold holds up when the textbook says it should fall.'],
      ['p', 'Their buying tends to be reported with a delay, so it rarely explains a move on a given day. It matters more over months and years.'],
    ],
  },
  {
    slug: 'priced-in',
    title: 'Why gold sometimes ignores the news',
    summary: 'Good news, gold falls. Bad news, gold rises. Here is what is going on.',
    body: [
      ['p', 'The verdicts on this site are the textbook reading of each story. They tell you what the news usually means for gold. They do not tell you what gold will do next, and it often does something else.'],
      ['h2', 'Common reasons'],
      ['ul', [
        'Priced in: traders expected the news and already bought or sold ahead of it.',
        'Something bigger is happening: a falling dollar can outweigh a bad jobs number.',
        'Profit taking: after a big run, traders sell into any good news to lock in gains.',
        'Forced selling: in a market panic, traders sell whatever they can, including gold, to raise cash.',
      ]],
      ['p', 'So when gold goes the "wrong" way, the story has not failed. It is usually telling you what traders already believed.'],
    ],
  },
];

export const guideBySlug = (slug) => GUIDES.find((g) => g.slug === slug) ?? null;
