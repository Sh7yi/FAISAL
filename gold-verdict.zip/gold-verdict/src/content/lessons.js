// One short lesson closes each morning brief, rotating through this list.
export const LESSONS = [
  'An election does not move gold directly. It moves the dollar and US interest rates, and gold follows them.',
  'Gold pays no interest. When savings accounts and bonds pay more, holding gold costs you more in lost income.',
  'Gold is priced in dollars. When the dollar falls, gold gets cheaper for everyone else, so more people buy.',
  'What matters is the surprise. A jobs number that was expected rarely moves gold, however big it is.',
  'War does not always lift gold. If it pushes oil up, inflation and interest rates can stay high, and that hurts gold.',
  'The Fed\'s words can matter more than its decision. Gold often moves on hints about the next meeting.',
  'Central banks buy gold in huge amounts and tend not to care about this week\'s price. That gives gold a slow, steady support.',
  'Real yields, meaning bond yields minus inflation, are the closest thing gold has to a rival.',
  'Gold can fall on good news for gold if traders had already bought ahead of it. That is called being priced in.',
  'In a sudden stock market crash, gold can fall too, because traders sell whatever they can to raise cash.',
];

export const lessonFor = (dateStr) => {
  const n = Math.floor(Date.parse(`${dateStr}T12:00:00Z`) / 864e5);
  return LESSONS[n % LESSONS.length];
};
