import { changes, topStories } from './state.js';
import { isMarketDay, longDate, marketStatus, weekdayName } from '../lib/time.js';
import { money, pct, sentence } from '../lib/format.js';

export const verdictWords = { bullish: 'bullish', bearish: 'bearish', mixed: 'mixed' };

// Builds the one-glance answer at the top of the page.
export function heroModel(state, now = new Date()) {
  const date = state.today?.date;
  const price = state.price?.usd ?? null;
  const change = changes(state);
  const day = change.day;
  const status = marketStatus(now);
  const market = date ? isMarketDay(date) : status.open;
  const dir = day ? (day.pct > 0.03 ? 'up' : day.pct < -0.03 ? 'down' : 'flat') : null;
  const storyDir = market && (dir === 'up' || dir === 'down') ? dir : null;
  const top = topStories(state.today, 1, storyDir)[0] ?? null;

  let question;
  if (!market) {
    const session = day?.session ? weekdayName(day.session) : 'its last session';
    question = dir === 'up' ? `Why did gold rise on ${session}?`
      : dir === 'down' ? `Why did gold fall on ${session}?`
        : 'Why did gold move last session?';
  } else if (dir === 'up') question = 'Why is gold up today?';
  else if (dir === 'down') question = 'Why is gold down today?';
  else if (dir === 'flat') question = 'Why is gold flat today?';
  else question = 'Why is gold moving today?';

  let priceLine;
  if (price === null) priceLine = 'Gold price is loading.';
  else if (!day) priceLine = `Gold is at ${money(price)}. The change on the day appears after the first daily close is recorded.`;
  else if (!market) priceLine = `Gold ended its last session ${dir === 'flat' ? 'flat' : dir} ${pct(Math.abs(day.pct)).replace('+', '')} and is quoted at ${money(price)}.`;
  else if (dir === 'flat') priceLine = `Gold is flat today at ${money(price)}.`;
  else priceLine = `Gold is ${dir} ${pct(Math.abs(day.pct)).replace('+', '')} today at ${money(price)}.`;

  let storyLine = 'No big gold story so far today. Quiet days often just follow the dollar and US interest rates.';
  let whyLine = top?.why ?? '';
  if (top) {
    const reading = top.verdict === 'mixed' ? 'it could cut either way for gold' : `${top.verdict} for gold`;
    const wanted = storyDir === 'up' ? 'bullish' : storyDir === 'down' ? 'bearish' : null;
    const opposite = storyDir === 'up' ? 'bearish' : storyDir === 'down' ? 'bullish' : null;
    const lead = top.verdict === wanted ? 'The story that best fits' : 'The biggest story';
    storyLine = `${lead}: ${sentence(top.title)} The usual reading: ${reading}.`;
    if (top.verdict === wanted) {
      const against = topStories(state.today, 10).find((s) => s.verdict === opposite && s.importance === 'high');
      if (against) whyLine += ` Pulling the other way: ${sentence(against.title)}`;
    } else if (top.verdict === opposite) {
      whyLine += ' Gold is moving against the textbook here, which often means the news was already priced in or something else is driving the market.';
    }
  }

  return {
    dateLabel: date ? longDate(date) : '',
    question,
    priceLine,
    storyLine,
    whyLine,
    price,
    change,
    dir,
    top,
    status,
    updatedAt: state.lastTickAt,
    titleTag: question,
  };
}
