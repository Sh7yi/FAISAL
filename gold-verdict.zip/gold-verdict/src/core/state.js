import { isMarketDay, mondayOf } from '../lib/time.js';

// Pegged currencies are the fallback if the exchange-rate feed is ever down.
export const PEGGED_FX = { USD: 1, AED: 3.6725, SAR: 3.75, QAR: 3.64, OMR: 0.3845, BHD: 0.376 };

export function newDay(date) {
  return { date, posts: [], snapshots: [], moveLevel: 0, briefDone: false, reopenDone: false };
}

export function newState() {
  return {
    version: 1,
    lastTickAt: null,
    firstTickDone: false,
    historySeeded: false,
    price: null,
    metals: {},
    closes: { XAU: {} },
    today: null,
    days: [],
    seen: {},
    recent: [],
    calendar: { fetchedAt: null, events: [] },
    fx: { fetchedAt: null, rates: { ...PEGGED_FX } },
    rates: { fetchedAt: null, series: {} },
    sources: {},
    reminders: {},
    outbox: [],
    telegram: { date: null, count: 0, ok: null, error: null },
    ai: { date: null, count: 0, ok: null, error: null },
  };
}

export function lastCloseBefore(closes = {}, date) {
  let best = null;
  for (const d of Object.keys(closes)) if (d < date && (!best || d > best)) best = d;
  return best ? { date: best, value: closes[best] } : null;
}

function change(price, base) {
  if (!base || !price || !base.value) return null;
  return { base: base.value, date: base.date, abs: price - base.value, pct: ((price - base.value) / base.value) * 100 };
}

// How far gold has moved since the last close of the day, week, month and year.
export function changes(state, price = state.price?.usd, symbol = 'XAU', date = state.today?.date) {
  const closes = state.closes[symbol] ?? {};
  if (!date) return { day: null, week: null, month: null, year: null };
  let day;
  if (isMarketDay(date)) {
    day = change(price, lastCloseBefore(closes, date));
  } else {
    // Market shut: "today" is the last session, its close against the one before.
    const last = lastCloseBefore(closes, date);
    const prior = last ? lastCloseBefore(closes, last.date) : null;
    day = last ? change(last.value, prior) : null;
    if (day) day.session = last.date;
  }
  return {
    day,
    week: change(price, lastCloseBefore(closes, mondayOf(date))),
    month: change(price, lastCloseBefore(closes, `${date.slice(0, 7)}-01`)),
    year: change(price, lastCloseBefore(closes, `${date.slice(0, 4)}-01-01`)),
  };
}

const IMPORTANCE = { high: 2, medium: 1, low: 0 };

// The stories that best explain the day. If gold has a direction, stories that fit it
// come first. Then biggest first, with the newest breaking ties.
export function topStories(day, limit = 3, direction = null) {
  const wanted = direction === 'up' ? 'bullish' : direction === 'down' ? 'bearish' : null;
  const fit = (post) => {
    if (!wanted) return 0;
    if (post.verdict === wanted) return 2;
    return post.verdict === 'mixed' ? 1 : 0;
  };
  return (day?.posts ?? [])
    .filter((p) => (p.type === 'news' || p.type === 'developing') && p.verdict)
    .sort((a, b) => fit(b) - fit(a) || (IMPORTANCE[b.importance] ?? 0) - (IMPORTANCE[a.importance] ?? 0) || b.at.localeCompare(a.at))
    .slice(0, limit);
}
