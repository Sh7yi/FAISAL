import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

// Loads a local .env if there is one (handy on your own computer; Render sets these itself).
function loadDotEnv() {
  const file = join(ROOT, '.env');
  if (!existsSync(file)) return;
  for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^["']|["']$/g, '');
  }
}

export function loadConfig(env = process.env) {
  if (env === process.env) loadDotEnv();
  const site = JSON.parse(readFileSync(join(ROOT, 'site.config.json'), 'utf8'));
  const sources = JSON.parse(readFileSync(env.SOURCES_FILE || join(ROOT, 'config/sources.json'), 'utf8'));
  const siteUrl = (site.siteUrl || env.RENDER_EXTERNAL_URL || '').replace(/\/$/, '');
  return {
    ...site,
    siteUrl,
    sources,
    port: Number(env.PORT) || 3000,
    tickMinutes: Number(env.TICK_MINUTES) || site.tickMinutes || 5,
    assetVersion: (env.RENDER_GIT_COMMIT || 'dev').slice(0, 8),
    github: {
      token: env.GITHUB_DATA_TOKEN || '',
      repo: env.GITHUB_DATA_REPO || env.RENDER_GIT_REPO_SLUG || '',
      branch: env.GITHUB_DATA_BRANCH || 'data',
      api: env.GITHUB_API || 'https://api.github.com',
    },
    telegram: { token: env.TELEGRAM_BOT_TOKEN || '', chatId: env.TELEGRAM_CHAT_ID || '' },
    ai: {
      key: env.ANTHROPIC_API_KEY || '',
      model: env.ANTHROPIC_MODEL || 'claude-haiku-5-5',
      version: env.ANTHROPIC_VERSION || '2026-10-21',
      dailyLimit: Number(env.AI_DAILY_LIMIT) || 400,
    },
    goldApiKey: env.GOLD_API_KEY || '',
    dataDir: env.DATA_DIR || join(ROOT, '.data'),
    runCollector: env.RUN_COLLECTOR !== 'false',
  };
}
