# Gold Verdict

A website that answers one question all day: **why is gold moving today?**

Every few minutes it checks the gold price and a set of news feeds. Each story that could
matter for gold gets a verdict (bullish, bearish or mixed) and a one-line reason in plain
English. It also has a news calendar with phone reminders, a gold calculator, gold rates by
country and karat, a markets page, short lessons, and an archive of past days.

It installs nothing extra, needs no database, and runs on Render's free plan.

## Put it online

### 1. Upload to GitHub

1. Go to https://github.com/new, name the repository `gold-verdict`, and click **Create repository**. Private or public both work.
2. On the next page click **uploading an existing file**.
3. Open this project folder, select everything inside it, and drag it onto the page.
4. Click **Commit changes**.

### 2. Connect to Render

1. Go to https://dashboard.render.com and sign up with your GitHub account.
2. Click **New > Blueprint**.
3. Click **Connect** next to `gold-verdict`. If it is not listed, connect your GitHub account and give Render access to that repository.
4. Enter a name, keep the `main` branch, and click **Deploy Blueprint**.
5. Wait a few minutes, then open your service. Its address is shown at the top, such as `https://gold-verdict.onrender.com`.

The site is now live. From here, every change you commit to `main` on GitHub redeploys it automatically.

### 3. Keep your history safe (recommended)

Render's free plan wipes the disk on every restart. To keep past days and prices, the site can
save them to a separate `data` branch of your GitHub repository.

1. On GitHub: profile picture > **Settings** > **Developer settings** > **Personal access tokens** > **Fine-grained tokens** > **Generate new token**.
2. Under **Repository access** choose **Only select repositories** and pick `gold-verdict`.
3. Under **Permissions**, set **Contents** to **Read and write**, then click **Generate token** and copy it.
4. On Render: open your service > **Environment** > **+ Add Environment Variable**. Set the key to `GITHUB_DATA_TOKEN` and paste the token as the value.
5. Choose **Save and deploy**.

If the token has an end date, make a new one before it runs out. The status page tells you if saving starts failing.

### 4. Keep it awake (recommended)

Render's free plan puts the site to sleep after 15 minutes with no visitors. While it sleeps, it
collects no news, and the next visitor waits about a minute. A free scheduled ping prevents this.

1. Sign up at https://cron-job.org.
2. Create a job for `https://YOUR-SITE.onrender.com/healthz`, running every 10 minutes.

Render gives you 750 free hours a month, and one site awake all month uses up to 744. So don't
run a second free service in the same Render workspace. To remove the limits altogether, move
the service to a paid instance.

### 5. Check it is working

Open `https://YOUR-SITE.onrender.com/status`. It shows whether each data source answered on the
last check, and whether saving to GitHub is working. A news source marked as failing can be
replaced in `config/sources.json`. The site carries on without it.

## Optional extras

Add these on Render under **Environment**.

| Key | What it does | Where to get it |
| --- | --- | --- |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` | Posts each big story, brief and reminder to your Telegram channel | See below |
| `GOLD_API_KEY` | Fills in about a year of past prices on the first run, so the week, month and year changes work from day one. Those past values are daily averages, not exact closes | Free account at https://gold-api.com |
| `ANTHROPIC_API_KEY` | Claude writes the verdicts and reasons instead of the built-in rules. Better judgement, and it costs a few cents a day at most | https://console.anthropic.com |

Without `GOLD_API_KEY`, the daily change appears after gold's first close at 5pm New York time,
and the longer changes fill in as time passes.

### Set up Telegram

1. In Telegram, message **@BotFather**, send `/newbot`, and copy the token it gives you.
2. Create a public channel and add your bot as an administrator.
3. Set `TELEGRAM_BOT_TOKEN` to the token, and `TELEGRAM_CHAT_ID` to `@your_channel_name`.
4. Put your channel's public link in `telegramUrl` in `site.config.json`, so the join buttons appear on the site.

## Make it your own

Everything you are likely to change is in `site.config.json`.

| Setting | Meaning |
| --- | --- |
| `name`, `tagline` | Your site's name and description |
| `siteUrl` | Leave blank on Render, or set it if you add your own domain |
| `telegramUrl` | Your public channel link. Telegram buttons stay hidden until this is set |
| `contactEmail` | Shown in the footer if you set it |
| `timeZone`, `timeZoneLabel` | Used for the morning brief and Telegram times |
| `localCurrency` | The currency shown first on the calculator and gold rate page |
| `morningBriefHour` | The hour the morning brief goes out, in your time zone |
| `tickMinutes` | How often it checks for news |

Colours are at the top of `public/styles.css`. The small "V" logo is in `src/views/layout.js` and `public/favicon.svg`.
Lessons are in `src/content/guides.js`. News feeds are in `config/sources.json`.

## Run it on your own computer

You need Node.js 22 or newer.

```
npm run demo    # sample data, no internet needed, at http://localhost:3000
npm start       # the real thing, using live feeds
npm test        # runs the checks
```

## How it works

```
Render web service (Node, no dependencies)
 ├─ Every 5 minutes: price, news, calendar  >  verdicts  >  posts  >  Telegram
 ├─ Serves the pages, calendar file and live updates
 └─ Saves to the "data" branch of your GitHub repo (or a temporary folder without a token)
Visitor's browser
 └─ Fetches the live price directly from gold-api.com every 30 seconds
```

Render only redeploys when `main` changes, so saving to the `data` branch does not trigger a deploy.
That branch holds a single commit that is replaced on each save, so your repository stays small.

## Good to know

- **Verdicts can be wrong.** The built-in rules read headlines by keyword. They give the usual textbook reading, not a forecast, and they will sometimes miss or misread a story.
- **News can lag.** Stories appear when the publisher's feed updates and the next check runs, usually within a few minutes.
- **Market holidays aren't tracked.** On a holiday the site may show the market as open while the price stands still.
- **Data sources have their own terms.** Before running ads or charging money, read the terms of the news feeds and the calendar and consider your own licences. gold-api.com's terms allow commercial use. ExchangeRate-API's open feed asks for the credit link that is already in the footer.
- **The legal pages are a starting point.** Have the disclaimer, privacy and terms pages reviewed if the site becomes a business.
